﻿**Departamento Académico de Ingeniería ![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.001.png)C8286-Computación Paralela y Distribuida** 

**Proyectos Finales**

Este documento presenta los detalles de los proyectos finales del curso de Computación Paralela y Distribuida C8286. Los proyectos se han diseñado para abordar problemas reales en diversas áreas como la visión computacional, la seguridad informática, el análisis de datos en tiempo real y la gestión de infraestructura como código.

Cada proyecto se ha estructurado en tres sprints, proporcionando un enfoque iterativo y incremental que permite a los participantes desarrollar y optimizar sus sistemas a lo largo del tiempo. Este método asegura que los proyectos evolucionen de manera constante y que se implementen mejoras basadas en pruebas y retroalimentación continua.

Cada sprint tiene objetivos claros y tareas específicas que te guían a través de la implementación, optimización y presentación de sus sistemas. Se ha puesto un énfasis especial en la capacidad de los para presentar sus proyectos, demostrando no solo la funcionalidad técnica de sus sistemas sino también su comprensión profunda de los conceptos y técnicas aplicadas.

Las exposiciones finales serán una oportunidad crucial para que los estudiantes muestren sus logros, discutan los desafíos enfrentados y presenten las soluciones innovadoras que han desarrollado. Este enfoque garantiza que los estudiantes no solo adquieran habilidades técnicas avanzadas, sino que también desarrollen competencias en comunicación y presentación, esenciales para su futuro profesional.

**Fechas tentativas de avance de los sprints**

Para asegurar un progreso ordenado y cumplir con la fecha de presentación final el 3 de julio, se establece el siguiente cronograma para los sprints de todos los proyectos (referencia). Los sprints se han distribuido de manera equitativa para cubrir las actividades necesarias de cada proyecto.

- **Sprint 1 (Diseño e implementación básica):** 1 de junio - 12 de junio
- **Sprint 2 (Algoritmos de detección y análisis distribuido):** 13 de junio - 23 de junio • **Sprint 3 (Optimización y presentación):** 24 de junio - 1 de julio

**Proyecto 3: Orquestación de microservicios con Docker y Kubernetes – Alejandra Lima Objetivo del Proyecto:**

Desarrollar y orquestar una arquitectura de microservicios utilizando Flask, Docker y Kubernetes para implementar una aplicación web escalable y modular.

**DESARROLLO**

**Sprint 1: Diseño y desarrollo de una arquitectura de microservicios utilizando Flask y Docker Objetivos:**

- Diseñar la arquitectura de microservicios.
- Desarrollar y contenedorar los servicios básicos utilizando Flask y Docker.

**Actividades:**

**Diseño de la arquitectura:**

- Dividir la aplicación en varios microservicios, cada uno con una responsabilidad específica (por ejemplo, servicio de autenticación, servicio de usuarios, servicio de productos, servicio de pedidos).
- Definir las interfaces y puntos de comunicación entre los microservicios (por ejemplo, APIs RESTful).

**Desarrollo de microservicios:**

- Crear aplicaciones Flask para cada microservicio.
- Implementar las funcionalidades básicas de cada servicio (por ejemplo, endpoints para CRUD).

**Dockerización de microservicios:**

- Escribir archivos Dockerfile para cada microservicio.
- Construir imágenes Docker y probar los contenedores localmente.

**Entregables:**

- Diagramas de la arquitectura de microservicios.
- Código fuente de los microservicios con Flask.
- Archivos Dockerfile para cada microservicio.
- Imágenes Docker construidas y contenedores probados localmente.

**Configurar el entorno de desarrollo:**

Tener Python 3 instalado. Podemos verificarlo ejecutando **python3 --version** en la terminal. Instalamos Flask, el framework web que utilizarás para desarrollar los microservicios.

**pip3 install flask**

Instalamos Docker:

**sudo apt-get update**

**sudo apt-get install -y docker.io**

Verificamos que Docker se haya instalado correctamente ejecutando **docker --version. Diseño de la arquitectura:**

En este caso, los microservicios que se deben identificar son:

- Servicio de autenticación
- Servicio de usuarios
- Servicio de productos
- Servicio de pedidos

Las responsabilidades de cada uno de estos servicios.

- El servicio de autenticación se encargará de gestionar el inicio y cierre de sesión de los usuarios.
- El servicio de usuarios se encargará de crear, leer, actualizar y eliminar usuarios.
- El servicio de productos se encargará de gestionar el catálogo de productos.
- El servicio de pedidos se encargará de crear, leer, actualizar y eliminar pedidos.

Definimos las interfaces y puntos de comunicación:

La forma más común de comunicación entre microservicios es a través de APIs RESTful.

Para cada microservicio, identifica qué endpoints o recursos necesitarán exponer para que otros servicios puedan interactuar con ellos.

Endpoints para cada microservicio: Servicio de autenticación:

- POST /login: Iniciar sesión
- POST /logout: Cerrar sesión
- Servicio de usuarios:

●

- GET /users: Obtener la lista de usuarios
- GET /users/{id}: Obtener los detalles de un usuario
- POST /users: Crear un nuevo usuario
- PUT /users/{id}: Actualizar los datos de un usuario
- DELETE /users/{id}: Eliminar un usuario

Servicio de productos:

- GET /products: Obtener la lista de productos
- GET /products/{id}: Obtener los detalles de un producto
- POST /products: Crear un nuevo producto
- PUT /products/{id}: Actualizar los datos de un producto
- DELETE /products/{id}: Eliminar un producto

Servicio de pedidos:

●

- GET /orders: Obtener la lista de pedidos
- GET /orders/{id}: Obtener los detalles de un pedido
- POST /orders: Crear un nuevo pedido
- PUT /orders/{id}: Actualizar los datos de un pedido
- DELETE /orders/{id}: Eliminar un pedido

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.002.png)

**Desarrollo de microservicios:**

Creamos un directorio para cada microservicio en mi sistema **mkdir auth-service**

**mkdir users-service**

**mkdir products-service**

**mkdir orders-service**

Desarrollamos los 4 microservicios:

**Servicio de Autenticación (auth-service/app.py):** from flask import Flask, jsonify, request

app = Flask(\_\_name\_\_)

@app.route('/login', methods=['POST']) def login():

username = request.json['username'] password = request.json['password']

- Aquí iría la lógica de autenticación return jsonify({'token': 'abc123'})

@app.route('/healthcheck', methods=['GET']) def healthcheck():

return jsonify({'status': 'OK'})

if \_\_name\_\_ == '\_\_main\_\_':

app.run(host='0.0.0.0', port=5000, debug=True)

**Servicio de Usuarios (users-service/app.py):** from flask import Flask, jsonify, request

app = Flask(\_\_name\_\_)

@app.route('/users', methods=['GET'])

def get\_users():

users = [{'id': 1, 'name': 'John Doe'}, {'id': 2, 'name': 'Jane Doe'}] return jsonify(users)

@app.route('/users/<int:user\_id>', methods=['GET']) def get\_user(user\_id):

user = {'id': user\_id, 'name': 'John Doe'}

return jsonify(user)

@app.route('/users', methods=['POST'])

def create\_user():

data = request.json

return jsonify({'id': 3, 'name': data['name']}), 201

@app.route('/healthcheck', methods=['GET']) def healthcheck():

return jsonify({'status': 'OK'})

if \_\_name\_\_ == '\_\_main\_\_':

app.run(host='0.0.0.0', port=5001, debug=True)

**Servicio de Productos (products-service/app.py):** from flask import Flask, jsonify, request

app = Flask(\_\_name\_\_)

@app.route('/products', methods=['GET'])

def get\_products():

products = [{'id': 1, 'name': 'Producto 1', 'price': 10.99},

{'id': 2, 'name': 'Producto 2', 'price': 15.50}] return jsonify(products)

@app.route('/products/<int:product\_id>', methods=['GET'])

def get\_product(product\_id):

product = {'id': product\_id, 'name': 'Producto 1', 'price': 10.99} return jsonify(product)

@app.route('/products', methods=['POST'])

def create\_product():

data = request.json

return jsonify({'id': 3, 'name': data['name'], 'price': data['price']}), 201

@app.route('/healthcheck', methods=['GET']) def healthcheck():

return jsonify({'status': 'OK'})

if \_\_name\_\_ == '\_\_main\_\_':

app.run(host='0.0.0.0', port=5002, debug=True)

**Servicio de Pedidos (orders-service/app.py):** from flask import Flask, jsonify, request

app = Flask(\_\_name\_\_)

@app.route('/orders', methods=['GET'])

def get\_orders():

orders = [{'id': 1, 'user\_id': 1, 'total': 25.99},

{'id': 2, 'user\_id': 2, 'total': 48.75}] return jsonify(orders)

@app.route('/orders/<int:order\_id>', methods=['GET']) def get\_order(order\_id):

order = {'id': order\_id, 'user\_id': 1, 'total': 25.99} return jsonify(order)

@app.route('/orders', methods=['POST']) def create\_order():

data = request.json

return jsonify({'id': 3, 'user\_id': data['user\_id'], 'total': data['total']}), 201

@app.route('/healthcheck', methods=['GET']) def healthcheck():

return jsonify({'status': 'OK'})

if \_\_name\_\_ == '\_\_main\_\_':

app.run(host='0.0.0.0', port=5004, debug=True)

**PROBANDO MICROSERVICIOS**

Abrimos una terminal y ejecutamos el servicio de autenticación: **cd auth-service**

**python3 app.py**

En otra terminal:

**curl -X POST -H "Content-Type: application/json" -d '{"username":"testuser","password":"testpassword"}' http://localhost:5000/login**

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.003.png)

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.004.png)

Esto indica que el servicio de autenticación está funcionando correctamente y respondiendo a la solicitud de inicio de sesión.

**Abrimos una nueva terminal y ve al directorio del servicio de usuarios: cd users-service**

Ejecutamos el servicio de usuarios:

**python3 app.py**

Abrimos una tercera terminal y probamos los endpoints del servicio de usuarios:

**curl [http://localhost:5001/users**](http://localhost:5001/users)**

**curl http://localhost:5001/users/1**

**curl -X POST -H "Content-Type: application/json" -d '{"name":"John Doe"}' http://localhost:5001/users**

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.005.png)

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.006.jpeg)

**Abrimos una terminal y ejecutamos Servicio de productos** Ejecuta el servicio de productos

**cd products-service**

**python3 app.py**

Prueba el servicio de productos en la misma terminal: **curl http://localhost:5002/products**

**curl http://localhost:5002/products/1**

**curl -X POST -H "Content-Type: application/json" -d '{"name":"Producto 3","price":20.99}' http://localhost:5002/products**

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.007.jpeg)

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.008.jpeg)

**Abrir una terminal y ejecutar Servicio de pedidos**

**cd orders-service python3 app.py**

Prueba el servicio de pedidos en la misma terminal: **curl http://localhost:5004/orders**

**curl http://localhost:5004/orders/1**

**curl -X POST -H "Content-Type: application/json" -d '{"user\_id":1,"total":25.99}' http://localhost:5004/orders**

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.009.png)

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.010.jpeg)

**Creamos requirements.txt para cada uno de los microservicios.**

**Servicio de Autenticación (auth-service/requirements.txt):**

flask

Este servicio solo necesita la biblioteca Flask para su funcionamiento.

**Servicio de Usuarios (users-service/requirements.txt):**

flask

Al igual que el servicio de autenticación, el servicio de usuarios solo necesita la biblioteca Flask. **Servicio de Productos (products-service/requirements.txt):**

flask

Este servicio también solo necesita la biblioteca Flask.

**Servicio de Pedidos (orders-service/requirements.txt):**

flask

El servicio de pedidos, al igual que los demás, solo necesita la biblioteca Flask.

**Se podría mejorar**

Por ejemplo, si el servicio de usuarios necesitará una biblioteca adicional como sqlalchemy para interactuar con una base de datos, el archivo requirements.txt quedaría así:

**flask sqlalchemy**

**Dockerización de microservicios:**

Después de haber desarrollado y probado individualmente cada uno de los microservicios, el siguiente paso es dockerizar estos servicios.

**Crear los archivos Dockerfile:**

Vamos a crear los archivos Dockerfile para cada uno de los microservicios: **Servicio de Autenticación (auth-service/Dockerfile):**

FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .

RUN pip3 install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 5000

CMD ["python3", "app.py"]

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.011.png)

**Servicio de Usuarios (users-service/Dockerfile):** FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .

RUN pip3 install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 5001

CMD ["python3", "app.py"]

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.012.png)

**Servicio de Productos (products-service/Dockerfile):** FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .

RUN pip3 install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 5002

CMD ["python3", "app.py"]

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.013.png)

**Servicio de Pedidos (orders-service/Dockerfile):** FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .

RUN pip3 install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 5004

CMD ["python3", "app.py"]

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.014.png)

**Estos Dockerfiles siguen el mismo patrón:**

- Utilizan la imagen base python:3.9-slim para tener un entorno Python optimizado y de tamaño reducido.
- Establecen el directorio de trabajo en /app.
- Copian el archivo requirements.txt y ejecutan pip3 install para instalar las dependencias.
- Copian todo el código fuente de la aplicación al contenedor.
- Exponen el puerto correspondiente a cada microservicio.
- Definen el comando de inicio de la aplicación python3 app.py.

**Construir imágenes Docker y probar los contenedores localmente.**

Servicio de Autenticación:

**cd auth-service**

**sudo docker build -t auth-service .**

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.015.jpeg)

Servicio de Usuarios:

**cd users-service**

**sudo docker build -t users-service .**

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.016.jpeg)

Servicio de Productos:

**cd products-service**

**sudo docker build -t products-service .**

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.017.jpeg)

Servicio de Pedidos:

**cd orders-service**

**sudo docker build -t orders-service .**

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.018.png)

Después de ejecutar estos comandos, deberías ver las imágenes Docker creadas en tu sistema: **sudo docker images**

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.019.png)

Ahora que tenemos las imágenes Docker construidas, podemos proceder a ejecutar los contenedores de cada microservicio.

**Ejecutar los contenedores Docker:**

Abre una nueva terminal y ejecuta los contenedores de cada microservicio: **sudo docker run -p 5000:5000 auth-service**

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.020.png)

Este comando ejecutará el contenedor del servicio de autenticación y mapeará el puerto 5000 del contenedor al puerto 5000 de mi máquina host. De esta manera, podre acceder al servicio de autenticación desde mi máquina.

**sudo docker run -p 5001:5001 users-service**

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.021.png)

**sudo docker run -p 5002:5002 products-service**

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.022.png)

**sudo docker run -p 5004:5004 orders-service**

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.023.png)

**Nota que estamos mapeando los puertos de los contenedores (5000) a puertos diferentes en la máquina host (5000, 5001, 5002, 5004) para evitar conflictos.**

**Probar los microservicios en contenedores Docker:**

Abre una nueva terminal y prueba los microservicios utilizando los puertos mapeados:

- **Servicio de autenticación**

curl -X POST -H "Content-Type: application/json" -d '{"username":"testuser","password":"testpassword"}' <http://localhost:5000/login>

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.024.png)

Esto indica que el servicio de autenticación está funcionando correctamente dentro del contenedor Docker.

- **Servicio de usuarios**

curl <http://localhost:5001/users>

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.025.png)

curl <http://localhost:5001/users/1>

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.026.png)

curl -X POST -H "Content-Type: application/json" -d '{"name":"John Doe"}' http://localhost:5001/users

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.027.png)

- **Servicio de productos**

curl http://localhost:5002/products curl http://localhost:5002/products/1

curl -X POST -H "Content-Type: application/json" -d '{"name":"Producto 3","price":20.99}' http://localhost:5002/products

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.028.jpeg)

- **Servicio de pedidos**

curl http://localhost:5004/orders curl http://localhost:5004/orders/1

curl -X POST -H "Content-Type: application/json" -d '{"user\_id":1,"total":25.99}' http://localhost:5004/orders

![](Aspose.Words.e7d40f78-dfd0-4c8f-a93b-1dd0efc263b8.029.jpeg)
