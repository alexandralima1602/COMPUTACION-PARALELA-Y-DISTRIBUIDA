﻿**Departamento Académico de Ingeniería ![ref1]C8286-Computación Paralela y Distribuida** 

**Actividad 2: Introducción a Docker**

.

**Objetivos**

1. Definir Docker y explicar su importancia en la industria de la tecnología de la información (IT).
1. Describir cómo Docker ha cambiado el uso de servidores y la implementación de aplicaciones.
1. Demostrar la capacidad para instalar Docker en diferentes sistemas operativos. Verificar la instalación de Docker para asegurar que esté correctamente configurada. 4. Ejecutar un contenedor Docker utilizando la imagen hello-world para validar que Docker está instalado y funcionando correctamente.
5. Identificar y describir los componentes clave de Docker, incluyendo imágenes, contenedores, volúmenes, y redes.
5. Entender la arquitectura de Docker y cómo interactúan sus componentes. 7. Enumerar casos de uso comunes para Docker y cómo puede ser utilizado para resolver problemas de desarrollo y operaciones (DevOps).
8. Analizar cómo Docker facilita el desarrollo, las pruebas, y la implementación de aplicaciones.
8. Crear imágenes Docker personalizadas utilizando un Dockerfile.
8. Comprender las mejores prácticas para la construcción de imágenes eficientes y seguras.
8. Describir los diferentes estados de un contenedor Docker (como en ejecución, detenido, pausado) y cómo gestionarlos.
8. Utilizar comandos para iniciar, detener, reiniciar y eliminar contenedores. 13. Explicar los fundamentos de la red Docker, incluyendo el aislamiento de red entre contenedores y la comunicación entre ellos.
14. Configurar y administrar redes Docker personalizadas.
14. Demostrar cómo utilizar volúmenes para persistir datos en contenedores Docker.
14. Diferenciar entre volúmenes, bind mounts, y tmpfs mounts y cuándo usar cada uno.
14. Realizar mantenimiento de Docker limpiando recursos no utilizados, como contenedores detenidos, imágenes no utilizadas, y volúmenes huérfanos. 18. Familiarizarse con los comandos más comunes de Docker y su uso para gestionar imágenes, contenedores, volúmenes, y redes.

**Docker para otras distribuciones de Linux**

Docker es compatible con la mayoría de las distribuciones y arquitecturas de Linux. Para obtener más información, consulta la página oficial en https://docs.docker.com/engine/install/.

**Probando la instalación de Docker (opcional)**

Computación Paralela y Distribuida ![ref1]

**Departamento Académico de Ingeniería C8286-Computación Paralela y Distribuida** 

Independientemente de la instalación que haya elegido (macOS, Windows, Ubuntu, Linux u otra), Docker debe estar configurado y listo. La mejor manera de probarlo es ejecutar el comando docker info. El mensaje de salida debe ser similar al siguiente:

$ docker info Containers: 0 Running: 0 Paused: 0 Stopped: 0 Images: 0

...

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.002.jpeg)

**Instalación en un servidor**

Para usar Docker en la red, es posible aprovechar los proveedores de plataformas en la nube o instalar Docker manualmente en un servidor dedicado. En el primer caso, la configuración de Docker difiere de una plataforma a otra, pero siempre está muy bien descrita en tutoriales dedicados. La mayoría de las plataformas en la nube permiten la creación de Docker hosts a través de interfaces web fáciles de usar o describen comandos exactos para ejecutar en sus servidores.

Sin embargo, el segundo caso (instalación manual de Docker y) requiere algunas palabras.

**Servidor dedicado**

La instalación manual de Docker en un servidor no difiere mucho de la instalación local. Se requieren dos pasos adicionales, que incluyen configurar el demonio Docker para escuchar en el socket de la red y configurar certificados de seguridad. Estos pasos se describen con más detalle aquí:

- Por defecto, por motivos de seguridad, Docker se ejecuta a través de un socket Unix fuera de la red que solo permite la comunicación local. Es necesario agregar escucha en el socket de la interfaz de red elegida para que los clientes externos puedan conectarse. En el caso de Ubuntu, el daemon de Docker es configurado por **systemd**, entonces, para cambiar la configuración de cómo se inicia, necesitamos modificar una línea en el archivo /lib/systemd/system/docker.service, de la siguiente manera:

ExecStart=/usr/bin/dockerd -H <server\_ip>:2375

Al cambiar esta línea, habilitamos el acceso al demonio Docker a través de la dirección IP (Protocolo de Internet) especificada. Todos los detalles sobre la configuración de systemd se pueden encontrar en https://docs.docker.com/config/daemon/systemd/.

- Este paso de la configuración del servidor se refiere a los certificados de seguridad de Docker. Esto permite que solo los clientes autenticados por un certificado

Computación Paralela y Distribuida ![ref1]

**Departamento Académico de Ingeniería C8286-Computación Paralela y Distribuida** 

accedan al servidor. Puedes encontrar una descripción completa de la configuración del certificado de Docker en https://docs.docker.com/engine/security/protect-access/. Este paso no es estrictamente necesario; sin embargo, a menos que tu servidor demonio Docker esté dentro de una red con firewall, es esencial. Información Si su demonio Docker se ejecuta dentro de una red corporativa, debes configurar el proxy del Protocolo de transferencia de hipertexto (HTTP). Puede encontrar una descripción detallada en https://docs.docker.com/config/daemon/systemd/.

Si su demonio Docker se ejecuta dentro de una red corporativa, debe configurar el proxy del

Protocolo de transferencia de hipertexto (HTTP). Puede encontrar una descripción detallada en https://docs.docker.com/config/daemon/systemd/.

El entorno de Docker está configurado y listo, por lo que podemos comenzar con el primer ejemplo.

**Ejecutando Docker hello-world**

Ingresa el siguiente comando en su consola:

$ docker run hello-world

Unable to find image 'hello-world:latest' locally

latest: Pulling from library/hello-world

1b930d010525: Pull complete

Digest: sha256:2557e3c07ed1e38f26e389462d03ed 943586f744621577a99efb77324b0fe535

Status: Downloaded newer image for hello-world:latest

Hello from Docker!

This message shows that your installation appears to be working

correctly.

...

¡Felicidades! Acaba de ejecutar tu primer contenedor Docker. Espero que ya puedas ver lo simple que es Docker. Examinemos lo que sucedió debajo del capó, de la siguiente manera:

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.003.jpeg)

**Pregunta 1**: Explica el procedimiento realizado en esta ejecución por línea de comandos.

**En la ejecución del comando "docker run hello-world", se realizó lo siguiente:**

- **Docker intentó encontrar la imagen "hello-world:latest" localmente, pero al no encontrarla, procedió a descargarla desde el repositorio "library/hello-world".**
- **Se descargó la imagen "hello-world:latest" al completo.**
- **Se mostró un mensaje indicando que la instalación de Docker parece estar funcionando correctamente.**
- **Finalmente, se imprimió el mensaje "Hello from Docker!", confirmando que el contenedor se ejecutó exitosamente.**

**En resumen, al ejecutar este comando, se descargó e inició un contenedor Docker utilizando la imagen "hello-world:latest", lo que demostró que la instalación de Docker está funcionando correctamente.**

**Componentes Docker**

Instalar Docker significa instalar todos los componentes para que el demonio Docker se ejecute en un equipo todo el tiempo como un servicio. En el caso del ejemplo de hello-world, usamos el cliente de Docker para interactuar con el demonio de Docker; sin embargo, podríamos hacer exactamente lo mismo usando la **API REST**. Además, en el caso del ejemplo de hello-world, nos conectamos al demonio Docker local. Sin embargo, podríamos usar el mismo cliente para interactuar con el demonio Docker que se ejecuta en una máquina remota.

Sugerencia: para ejecutar el contenedor Docker en una máquina remota, puedes usar la opción -H:

docker -H <server\_ip>:2375 run hello-world. **Imágenes y contenedores Docker**

Una imagen es un bloque de construcción sin estado (stateless) en el mundo de Docker. Puedes pensar en una imagen como una colección de todos los archivos necesarios para ejecutar tu aplicación, junto con los pasos sobre cómo ejecutarla. Una imagen no tiene estado, por lo que puedes enviarla a través de la red, almacenarla en el registro, nombrarla, versionarla y guardarla como un archivo. Las imágenes están en capas, lo que significa que puede construir una imagen encima de otra imagen.

Un contenedor es una instancia en ejecución de una imagen. Podemos crear muchos contenedores a partir de una misma imagen si queremos tener muchas instancias de la misma aplicación. Dado que los contenedores tienen estado (stateful), esto significa que

podemos interactuar con ellos y realizar cambios en sus estados. **Aplicaciones docker**

Se proporcionan muchas aplicaciones en forma de imágenes de Docker que se pueden descargar de Internet. Si conocemos el nombre de la imagen, bastaría con ejecutar de la misma forma que hicimos con el ejemplo de hello-world. ¿Cómo podemos encontrar la imagen de la aplicación deseada en Docker Hub?

Tomemos MongoDB como ejemplo. Estos son los pasos que debemos seguir: 1. Si queremos encontrarlo en Docker Hub, tenemos dos opciones, de la siguiente manera:

- Busca en la página Explorar de Docker Hub (https://hub.docker.com/search/). - Utiliza el comando docker search.

En el segundo caso, podemos realizar la siguiente operación: $ docker search mongo

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.004.jpeg)

2\. Hay muchas opciones interesantes. ¿Cómo elegimos la mejor imagen? Por lo general, el

más atractivo es el que no tiene ningún prefijo, ya que significa que es una imagen oficial de Docker Hub y, por lo tanto, debe ser estable y mantenerse. Las imágenes con prefijos no son oficiales, generalmente se mantienen como proyectos de código abierto. En nuestro caso, la mejor opción parece ser **mongo,** por lo que para ejecutar el servidor MongoDB, podemos ejecutar el siguiente comando:

**$ docker run mongo**

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.005.jpeg)

Eso es todo lo que tenemos que hacer. MongoDB ha comenzado.

Ejecutar aplicaciones como contenedores Docker es así de simple porque no necesitamos pensar en ninguna dependencia; todos se entregan junto con la imagen. Docker puede tratarse como una herramienta útil para ejecutar aplicaciones; sin embargo, el verdadero poder radica en crear tus propias imágenes de Docker que envuelvan los programas con el entorno.

Información En el servicio Docker Hub, puede encontrar muchas aplicaciones; almacenan millones de imágenes diferentes.

**Creación de imágenes de Docker**

En esta sección, veremos cómo crear imágenes de Docker utilizando dos métodos diferentes: el comando commit de Docker y una compilación automatizada de Dockerfile.

**docker commit**

Comencemos con un ejemplo y preparemos una imagen con los kits de herramientas de Git y JDK. Usaremos Ubuntu 20.04 como imagen base. No hay necesidad de crearlo; la mayoría de las imágenes base están disponibles en el registro de Docker Hub. Procede de la siguiente:

1. Ejecuta un contenedor desde ubuntu:20.04 y conéctelo a tu línea de comando, así: $ docker run -i -t ubuntu:20.04 /bin/bash

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.006.png)

Extrajimos la imagen de ubuntu:20.04, la ejecutamos como un contenedor y luego llamamos al comando /bin/bash de forma interactiva (marca -i). Deberías ver la Terminal del contenedor. Dado que los contenedores tienen estado y escritura, podemos hacer lo que queramos en tu Terminal.

2. Instala el kit de herramientas de Git de la siguiente manera:

root@dee2cb192c6c:/# apt-get update

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.007.jpeg)

root@dee2cb192c6c:/# apt-get install -y git

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.008.jpeg)

3. Comprueba si el kit de herramientas de Git está instalado ejecutando lo siguiente:

root@dee2cb192c6c:/# which git /usr/bin/git

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.009.png)

4. Salga del contenedor, así: root@dee2cb192c6c:/# exit

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.010.png)

5. Verifica qué ha cambiado en el contenedor comparando su identificador (ID) de contenedor único con la imagen de ubuntu, de la siguiente manera:

   $ docker diff dee2cb192c6c docker diff eee121bfa165

   me sale error

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.011.jpeg)

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.012.jpeg)

El comando anterior debe imprimir una lista de todos los archivos modificados en el contenedor.

6. Commit el contenedor a la imagen, así: $ docker commit dee2cb192c6c ubuntu-git docker commit eee121bfa165 ubuntu-git

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.013.png)

Acabamos de crear nuestra primera imagen de Docker. Enumeremos todas las imágenes del host Docker para ver si la imagen está presente, de la siguiente manera:

$docker images

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.014.jpeg)

Pregunta: ¿que resultado encuentras después de ejecutar el comando?, ¿aparece la imagen ubuntu-git?, ¿cuál es su tamaño?

Ahora, si creamos un contenedor a partir de la imagen, tendrás instalada la herramienta Git, como se ilustra en el siguiente fragmento de código:

$ docker run -i -t ubuntu-git /bin/bash root@3b0d1ff457d4:/# which git /usr/bin/git

root@3b0d1ff457d4:/# exit

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.015.png)

**Dockerfile**

Crear de manera manual cada imagen de Docker con el comando commit podría ser laborioso, especialmente en el caso de la automatización de compilación y el proceso de entrega continua (CD). Afortunadamente, hay un lenguaje incorporado para especificar todas las instrucciones que deben ejecutarse para crear una imagen de Docker. Comencemos con un ejemplo similar al de Git. Esta vez, prepararemos una imagen de ubuntu-python, de la siguiente manera:

1. Crea un nuevo directorio y un archivo llamado Dockerfile con el siguiente contenido:

FROM ubuntu:20.04

RUN apt-get update && \

apt-get install -y python

2. Ejecuta el siguiente comando para crear una imagen ubuntu-python: $ docker build -t ubuntu-python .

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.016.jpeg)

3. Comprueba que la imagen se creó ejecutando el siguiente comando: $ docker images

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.017.png)

Ahora podemos crear un contenedor a partir de la imagen y verificar que el intérprete de Python existe exactamente de la misma manera que lo hicimos después de ejecutar el comando docker commit. Ten en cuenta que la imagen de ubuntu aparece solo una vez, aunque es la imagen base para ubuntu-git y ubuntu-python.

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.018.png)

En este ejemplo, usamos las dos primeras instrucciones de Dockerfile, como se describe aquí:

- FROM define una imagen sobre la cual se construirá la nueva imagen ∉ RUN especifica los comandos que se ejecutarán dentro del contenedor.

Las otras instrucciones ampliamente utilizadas se detallan a continuación:.

- COPY/ADD copia un archivo o un directorio en el sistema de archivos de la imagen.
- ENTRYPOINT define qué aplicación debe ejecutarse en el contenedor ejecutable.

Puede encontrar una guía completa de todas las instrucciones de Dockerfile en la página oficial de Docker en https://docs.docker.com/engine/reference/builder/.

**Aplicación Docker completa**

Ya tenemos toda la información necesaria para crear una aplicación completamente funcional como una imagen de Docker. Como ejemplo, prepararemos, paso a paso, un programa simple de Python hello-world. Los pasos son siempre los mismos, independientemente del entorno o lenguaje de programación que utilicemos.

Esta es una aplicación muy simple, así que no deberías tener problemas con resolverla **Escribiendo la aplicación**

Crea un nuevo directorio y, dentro de este directorio, crea un archivo hola.py con el siguiente contenido:

print "¡Hola mundo desde Python!"

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.019.png)

Cierra el archivo. Este es el código fuente de nuestra aplicación.

**Preparando el entorno**

El entorno se expresa en el Dockerfile. Necesitamos instrucciones para definir lo siguiente:

- ¿Qué imagen base debe usarse?
- ¿Cómo instalar el intérprete de Python?
- ¿Cómo incluir hello.py en la imagen?
- ¿Cómo iniciar la aplicación?

En el mismo directorio, crea el Dockerfile, así:

FROM ubuntu:20.04

RUN apt-get update && \

apt-get install -y python COPY hola.py .

ENTRYPOINT ["python", "hola.py"]

**Construyendo la imagen**

Ahora, podemos construir la imagen exactamente de la misma manera que lo hicimos antes, de la siguiente manera:

$ docker build -t hola-python .

**Ejecutando la aplicación**

Ejecutamos la aplicación ejecutando el contenedor, así: $ docker run hola-python

¡Deberías ver un amistoso mensaje de Python. Lo más interesante de este ejemplo es que podemos ejecutar la aplicación escrita en Python sin tener instalado el intérprete de Python en nuestro sistema host. Esto es posible porque la aplicación empaquetada como una imagen ya tiene el entorno incluido.

Consejo: Ya existe una imagen con el intérprete de Python en el servicio Docker Hub, por lo que en un escenario real bastaría con utilizarlo.

**Ejercicio:** Este simple este ejercicio te guiará a través del proceso de configuración y ejecución de una simple aplicación cliente-servidor utilizando Python y Docker. El objetivo

es aprender cómo los contenedores Docker pueden ser utilizados para desplegar aplicaciones de manera aislada y eficiente.

Observación: Dado que los scripts parecen ser un cliente y un servidor diseñados para ejecutarse de manera independiente (uno esperando conexiones y el otro iniciando

Computación Paralela y Distribuida ![ref1]

**Departamento Académico de Ingeniería C8286-Computación Paralela y Distribuida** 

conexiones), probablemente quieras modificar la manera en que se diseñan para ejecutarse dentro de Docker.

Ten en cuenta que Docker está diseñado para ejecutar un proceso principal por contenedor, lo que significa que este enfoque de ejecutar múltiples procesos (el servidor y luego el cliente) en un único contenedor no es el ideal. Una mejor práctica sería tener un contenedor para el servidor y otro para el cliente.

Parte 1: Exploración y Ejecución Local

- Revisa el código fuente de **cliente.py** y **servidor.py** para entender cómo se realiza la comunicación entre cliente y servidor usando sockets en Python.
- Ejecuta primero **servidor.py** y luego **cliente.py** en la misma máquina para asegurarse de que la comunicación funcione correctamente. Puedes usar tmux.

.Parte 2: Introducción a Docker

- Analiza el **Dockerfile** proporcionado para entender cómo se construye la imagen Docker que contiene la aplicación cliente-servidor.
- Revisar el script **start.sh** para comprender cómo se inician el servidor y el cliente dentro del contenedor.

Parte 3: Construcción de la Imagen Docker:

- Utilizar el **Dockerfile** para construir una imagen Docker de la aplicación. - Ejecutar un contenedor basado en la imagen construida y observar la interacción entre el cliente y el servidor.

Parte 4: Manipulación de la red Docker

- Experimentar con la configuración de red de Docker para permitir la comunicación entre múltiples contenedores o entre el contenedor y el host.
- Modificar la aplicación para que el servidor escriba los mensajes recibidos a un archivo y configurar un volumen Docker para persistir estos datos fuera del contenedor.

**Preguntas**

- ¿Cómo facilita Docker el despliegue y la ejecución de aplicaciones cliente-servidor? • ¿Qué ventajas ofrece la contenerización para el desarrollo y la producción de aplicaciones?
- ¿Cómo se comparan los sockets en Python con otros métodos de comunicación en red en términos de complejidad y uso?
- ¿Cuáles serían los desafíos de escalar esta aplicación para manejar múltiples clientes simultáneamente?

**Estados del contenedor Docker** Computación Paralela y Distribuida ![ref1]

**Departamento Académico de Ingeniería C8286-Computación Paralela y Distribuida** 

Se suponía que todas las aplicaciones que hemos ejecutado hasta ahora debían hacer algún trabajo y detenerse; por ejemplo, hemos impreso ¡Hola mundo desde Docker! y salió. Sin embargo, hay aplicaciones que deben ejecutarse continuamente, como los servicios. Para ejecutar un contenedor en segundo plano, podemos usar la opción -d (--detach). Intentémoslo con la imagen de ubuntu, de la siguiente manera:

$ docker run -d -t ubuntu:20.04

Este comando inició el contenedor de Ubuntu pero no le adjuntó la consola. Podemos ver que se está ejecutando usando el siguiente comando:

$ docker ps

Este comando imprime todos los contenedores que se encuentran en estado de ejecución.

¿Qué pasa con nuestros contenedores viejos, ya salidos? Podemos encontrarlos imprimiendo todos los contenedores, así:

$ docker ps -a

Ten en cuenta que todos los contenedores antiguos están en un estado cerrado. Hay dos estados más que aún no hemos observado: en **paused** y **restarting**.

El uso de contenedores Docker paused es muy raro y, técnicamente, se realiza congelando los procesos mediante la señal SIGSTOP. restarting es un estado temporal cuando el contenedor se ejecuta con la opción --restart para definir una estrategia de reinicio (el demonio Docker puede reiniciar automáticamente el contenedor en caso de falla).

Por ejemplo, podemos dejar de ejecutar el contenedor de Ubuntu, como se muestra aquí: $docker stop 13181f811922

$ docker ps

CONTAINER ID IMAGE COMMAND CREATED STATUS PORTS NAMES

**Información**: Siempre hemos usado el comando **docker run** para crear e iniciar un contenedor. Sin embargo, es posible simplemente crear un contenedor sin iniciarlo (con **docker create)**.

Habiendo captado los detalles de los estados de Docker, describamos los conceptos básicos de redes dentro del mundo de Docker.

**Redes docker**

Computación Paralela y Distribuida ![ref1]

**Departamento Académico de Ingeniería C8286-Computación Paralela y Distribuida** 

La mayoría de las aplicaciones en estos días no se ejecutan de forma aislada; necesitan comunicarse con otros sistemas a través de la red. Si queremos ejecutar un sitio web, un servicio web, una base de datos o un servidor de caché dentro de un contenedor Docker, primero debemos comprender cómo ejecutar un servicio y exponer su puerto a otras aplicaciones.

**Servicios en uso**

Comencemos con un ejemplo simple y ejecutemos un servidor Tomcat directamente desde Docker Hub, de la siguiente manera:

$ docker run -d tomcat

Tomcat es un servidor de aplicaciones web a cuya interfaz de usuario se puede acceder por el puerto 8080. Por lo tanto, si instalamos Tomcat en nuestra máquina, podríamos navegar en http://localhost:8080. En nuestro caso, sin embargo, Tomcat se ejecuta dentro del contenedor Docker. Lo comenzamos de la misma manera que lo hicimos con el primer ejemplo. Podemos ver que se está ejecutando, de la siguiente manera:

$ docker ps

…

9b92be34d101 tomcat "catalina.sh run" 41 seconds ago Up 25 seconds 8080/tcp flamboyant\_turing

Dado que se ejecuta como un demonio (con la opción -d), no vemos los registros en la consola de inmediato. No obstante, podemos acceder a él ejecutando el siguiente código:

$ docker logs 9b92be34d101

Si no hay errores, deberíamos ver muchos registros, lo que indica que Tomcat se ha iniciado y es accesible a través del puerto 8080. Podemos intentar ir a http:// localhost:8080, pero no podremos conectarnos. Esto se debe a que Tomcat se inició dentro del contenedor y estamos tratando de alcanzarlo desde el exterior. En otras palabras, podemos alcanzarlo solo si nos conectamos con el comando a la consola en el contenedor y lo verificamos allí.

¿Cómo hacemos que ejecutar Tomcat sea accesible desde el exterior?

Necesitamos iniciar el contenedor, especificando la asignación de puertos con el indicador - p (--publish), de la siguiente manera:

-p, --publish <host\_port>:<container\_port>

Entonces, primero detengamos el contenedor en ejecución y comencemos uno nuevo, así: $ docker stop 9b92be34d101

Computación Paralela y Distribuida ![ref1]

**Departamento Académico de Ingeniería C8286-Computación Paralela y Distribuida** 

$ docker run -d -p 8080:8080 tomcat

Después de esperar unos segundos, Tomcat debería haberse iniciado y deberíamos poder abrir su página: http://localhost:8080.

Observación:

sudo netstat -pna | grep 3000 (ejecuta esto para ver si es que tienes alguna aplicación usando ese puerto)

netstat -nlp | grep 8080

sudo netstat -pna | grep 8080

sudo netstat -ltnp | grep ‘:6379’

Kill PID

Un comando de mapeo de puertos tan simple es suficiente en los casos de uso más comunes de Docker. Podemos implementar (micro) servicios como contenedores Docker y exponer sus puertos para facilitar la comunicación. Sin embargo, profundicemos un poco más.

Información Docker también nos permite publicar en la interfaz de red del host específico con -p

<ip>:<host\_port>:<container\_port> . **Redes de contenedores**

Nos hemos conectado a la aplicación que se está ejecutando dentro del contenedor. De hecho, la conexión es bidireccional porque, si recuerdas los ejemplos anteriores, ejecutamos los comandos apt-get install desde adentro y los paquetes se descargaron de Internet. ¿Cómo es esto posible?

Si revisas las interfaces de red en tu máquina, puedes ver que una de las interfaces se

llama docker0, como se ilustra aquí:

$ ifconfig docker0

docker0 Link encap:Ethernet HWaddr 02:42:db:d0:47:db

inet addr:172.17.0.1 Bcast:0.0.0.0 Mask:255.255.0.0 …

La interfaz docker0 es creada por el demonio Docker para conectarse con el contenedor Docker. Ahora, podemos ver qué interfaces se crean dentro del contenedor Tomcat Docker creado con el comando docker inspect, de la siguiente manera:

$ docker inspect 0e4bc5c3e311 Computación Paralela y Distribuida ![ref1]

**Departamento Académico de Ingeniería C8286-Computación Paralela y Distribuida** 

Esto imprime toda la información sobre la configuración del contenedor en formato de notación de objetos JavaScript (JSON). Entre otras cosas, podemos encontrar la parte relacionada con la configuración de la red, como se ilustra en el siguiente fragmento de código:

![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.020.png)

Si tienes algún problema escribe: docker run -d tomcat

Podemos observar que el contenedor Docker tiene una dirección IP de 172.17.0.3 y se comunica con el host Docker con una dirección IP de 172.17.0.1. Esto significa que en el ejemplo anterior, podríamos acceder al servidor Tomcat incluso sin el reenvío de puertos, usando http://172.17.0.2:8080. Sin embargo, en la mayoría de los casos, ejecutamos el contenedor Docker en una máquina servidor y queremos exponerlo afuera, por lo que

debemos usar la opción -p.

Ten en cuenta que, de forma predeterminada, los contenedores no abren ninguna ruta desde sistemas externos. Podemos cambiar este comportamiento predeterminado jugando con el indicador --network y configurándolo de la siguiente manera:

- bridge (predeterminado): red a través del puente Docker predeterminado
- none: sin red
- container: red unida con el otro contenedor (especificado)
- host: pila de red del host
  - NETWORK: red creada por el usuario (usando el comando docker network create)

Computación Paralela y Distribuida ![ref1]

**Departamento Académico de Ingeniería C8286-Computación Paralela y Distribuida** 

Las diferentes redes se pueden enumerar y administrar mediante el comando docker network, de la siguiente manera:

docker network ls

NETWORK ID NAME DRIVER SCOPE eec1a0d430cd bridge bridge local 0950592f1e74 host host local 40566fb001aa kind bridge local 21a6cb9dde76 minikube bridge local f4a46675576f none null local

Si especificamos **none** como red, no podremos conectarnos al contenedor, y viceversa; el contenedor no tiene acceso de red al mundo exterior. La opción **host** hace que las interfaces de red del contenedor (CNI) sean idénticas al host. Comparten las mismas direcciones IP, por lo que todo lo que comenzó en el contenedor es visible en el exterior. La opción más popular es la predeterminada (**bridge**) porque nos permite definir explícitamente qué puertos deben publicarse y es seguro y accesible.

**Exponiendo puertos de contenedores**

Mencionamos algunas veces que el contenedor expone el puerto. De hecho, si profundizamos en la imagen de Tomcat en GitHub (https://github.com/docker library/tomcat), podemos ver la siguiente línea en el Dockerfile:

EXPOSE 8080

Esta instrucción de Dockerfile estipula que el puerto 8080 debe estar expuesto desde el contenedor. Sin embargo, como ya hemos visto, esto no significa que el puerto se publique automáticamente. La instrucción EXPOSE solo informa a los usuarios qué puertos deben publicar.

**Asignación automática de puertos**

Intentemos ejecutar el segundo contenedor Tomcat sin detener el primero, de la siguiente manera:

$ docker run -d -p 8080:8080 tomcat 2bebd64a1d984e8a1fd151e57c598d8e05275e458bc05412fd2d63a16cecc57e docker: Error response from daemon: driver failed programming external connectivity on endpoint zen\_goldstine (8b42804068e0814ded93eb2faaba29b999f75f24a57ab947acff4d1786f68d75): Bind for 0.0.0.0:8080 failed: port is already allocated.

Computación Paralela y Distribuida ![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.021.png)

**Departamento Académico de Ingeniería C8286-Computación Paralela y Distribuida** 

Este error puede ser común. En tales casos, tenemos que encargarnos de la unicidad de los puertos por nuestra cuenta o dejar que Docker asigne los puertos automáticamente usando una de las siguientes versiones del comando **publish**:

- -p <container\_port>: publica el puerto del contenedor en el puerto del host no utilizado
- -p (--publish-all): publica todos los puertos expuestos por el contenedor en los puertos de host no utilizados, de la siguiente manera:

$ docker run -d -P tomcat

$ docker port 078e9d12a1c8

8080/tcp -> 0.0.0.0:32768 8080/tcp -> [::]:32768

Podemos ver que la segunda instancia de Tomcat se ha publicado en el puerto 32768, por lo que se puede navegar en http://localhost:32768.

**Volúmenes de Docker**

Imagina que te gustaría ejecutar una base de datos como un contenedor. Puedes iniciar dicho contenedor e ingresar datos. ¿Dónde se almacena? ¿Qué sucede cuando detiene el contenedor o lo detienes? Puedes iniciar uno nuevo, pero la base de datos volverá a estar vacía. A menos que sea tu entorno de prueba, esperarías que tus datos se conservaran de forma permanente.

Un volumen de Docker permite que el contenedor escriba en el sistema de archivos del host

como si estuviera escribiendo en el suyo propio.

Los volúmenes de Docker permiten la **persistencia y el uso compartido de los datos de un contenedor.** Los volúmenes también separan claramente el procesamiento de los datos. Comencemos con el siguiente ejemplo:

1. Especifica un volumen con la opción -v <host\_path>:<container\_path> y luego conecta al contenedor, de la siguiente manera:

   $ docker run -i -t -v ~/docker\_ubuntu:/host\_directorio ubuntu:20.04 /bin/bash

2. Crea un archivo vacío en host\_directorio en el contenedor, así: root@01bf73826624:/# touch /host\_directorio/archivo.txt
2. Comprueba si el archivo se creó en el sistema de archivos del Docker host ejecutando el siguiente comando:

   Computación Paralela y Distribuida ![](Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.022.png)

   **Departamento Académico de Ingeniería C8286-Computación Paralela y Distribuida** 

   root@01bf73826624:/# exit exit

   $ ls ~/docker\_ubuntu/ archivo.txt

4. Podemos ver que el sistema de archivos se compartió y, por lo tanto, los datos se conservaron de forma permanente. Detén el contenedor y ejecute uno nuevo para ver si el archivo todavía estará allí, de la siguiente manera:

   $ docker run -i -t -v ~/docker\_ubuntu:/host\_directorio ubuntu:20.04 /bin/bash root@a9e0df194f1f:/# ls /host\_directorio/

   archivo.txt

   root@a9e0df194f1f:/# exit

5. En lugar de especificar un volumen con el indicador -v, es posible especificarlo como una instrucción en el Dockerfile, como en el siguiente ejemplo:

   VOLUME /host\_directorio

En este caso, si ejecutamos el contenedor Docker sin el indicador -v, la ruta del contenedor /host\_directorio se asignará al directorio predeterminado del host para volúmenes, /var/lib/docker/vfs/. Esta es una buena solución si entregas una aplicación como una imagen y sabes que requiere almacenamiento permanente por algún motivo (por ejemplo, almacenar registros de aplicaciones).

**Los volúmenes de Docker pueden ser mucho más complicados, especialmente en el caso de las bases de datos.**

Un enfoque muy común para la gestión de datos con Docker es introducir una capa adicional, en forma de contenedores de volumen de datos. Un contenedor de volumen de datos es un contenedor Docker cuyo único propósito es declarar un volumen. Luego, otros contenedores pueden usarlo (con la opción --volumes-from <container>) en lugar de declarar el volumen directamente. Lee más en https://docs.docker.com/storage/volumes/.

**Uso de nombres en Docker**

Hasta ahora, cuando hemos operado en contenedores, siempre hemos usado nombres generados automáticamente. Este enfoque tiene algunas ventajas, como que los nombres sean únicos (sin conflictos de nombres) y automáticos (no es necesario hacer nada). En muchos casos, sin embargo, es mejor dar un nombre descriptivo a un contenedor o una imagen.

Computación Paralela y Distribuida ![ref2]

**Departamento Académico de Ingeniería C8286-Computación Paralela y Distribuida** 

**Contenedores de nombres**

Hay dos buenas razones para nombrar un contenedor: la conveniencia y la posibilidad de automatización. Veamos por qué, de la siguiente manera:

- Conveniencia: Es más sencillo realizar cualquier operación sobre un contenedor direccionando por su nombre que comprobando los hashes o el nombre autogenerado.
- Automatización: A veces, nos gustaría depender del nombre específico de un contenedor.

Por ejemplo, nos gustaría tener contenedores que dependan unos de otros y que estén enlazados unos con otros. Por lo tanto, necesitamos saber sus nombres.

Para nombrar un contenedor, usamos el parámetro --name, de la siguiente manera: $ docker run -d --name tomcat tomcat

Podemos verificar (con docker ps) que el contenedor tenga un nombre significativo. Además, como resultado, cualquier operación se puede realizar utilizando el nombre del contenedor, como en el siguiente ejemplo:

$ docker logs tomcat

Ten en cuenta que cuando se nombra un contenedor, no pierde su identidad. Todavía podemos dirigirnos al contenedor por su ID de hash generado automáticamente, tal como lo hicimos antes.

**Recuerda**: Un contenedor siempre tiene un ID y un nombre. Puede ser abordado por cualquiera de ellos, y ambos son únicos.

**Etiquetado de imágenes**

Las imágenes se pueden etiquetar. Por ejemplo, en el caso de construir la imagen paralelo\_python, como se ilustra aquí:

$ docker build -t paralelo\_python .

El indicador -t describe la etiqueta de la imagen. Si no lo usamos, la imagen se construirá sin ninguna etiqueta y, como resultado, tendríamos que redireccionar por su ID (hash) para poder ejecutar el contenedor. La imagen puede tener varias etiquetas y deben seguir esta convención de nomenclatura:

<registry\_address>/<image\_name>:<version> Una etiqueta consta de las siguientes partes:

Computación Paralela y Distribuida ![ref2]

**Departamento Académico de Ingeniería C8286-Computación Paralela y Distribuida** 

- registry\_address: IP y puerto del registro o el nombre de alias
- image\_name: nombre de la imagen que se construye, por ejemplo, ubuntu ∉ versión: una versión de la imagen en cualquier forma, por ejemplo, 20.04, 20170310

Si una imagen se mantiene en el registro oficial de Docker Hub, podemos omitir la dirección del registro. Es por eso que ejecutamos la imagen Tomcat sin ningún prefijo. La última versión siempre se etiqueta como la última y también se puede omitir, por lo que ejecutamos la imagen de Tomcat sin ningún sufijo.

Información Las imágenes suelen tener múltiples etiquetas; por ejemplo, estas tres etiquetas son la misma imagen: : ubuntu:18.04 , ubuntu:bionic-20190122 , and ubuntu:bionic .

**Limpieza de docker**

A lo largo de esta clase, hemos creado una serie de contenedores e imágenes. Sin embargo, esto es solo una pequeña parte de lo que verá en escenarios de la vida real. Incluso cuando los contenedores no se están ejecutando, deben almacenarse en docker host. Esto puede provocar rápidamente que se exceda el espacio de almacenamiento y se

detenga la máquina. ¿Cómo podemos abordar esta preocupación? **Limpieza de contenedores**

Primero, veamos los contenedores que están almacenados en nuestra máquina. Estos son los pasos que debemos seguir:

1. Para imprimir todos los contenedores (independientemente de su estado), podemos usar el comando docker ps -a, de la siguiente manera:

   $ docker ps -a

2. Para eliminar un contenedor detenido, podemos usar el comando docker rm (si un contenedor se está ejecutando, primero debemos detenerlo), de la siguiente manera:

   $ docker rm 47ba1c0ba90e

3. Si queremos eliminar todos los contenedores detenidos, podemos usar el siguiente comando:

   $ docker container prune

4. También podemos adoptar un enfoque diferente y pedirle al contenedor que se elimine tan pronto como se detenga usando el indicador --rm, como en el siguiente ejemplo:

Computación Paralela y Distribuida ![ref2]

**Departamento Académico de Ingeniería C8286-Computación Paralela y Distribuida** 

$ docker run --rm hello-world

En la mayoría de los escenarios de la vida real, no usamos contenedores detenidos y se dejan solo con fines de depuración.

**Limpieza de imágenes**

Limpiar las imágenes es tan importante como limpiar los contenedores. Pueden ocupar mucho espacio, especialmente en el caso del proceso de CD, cuando cada compilación termina en una nueva imagen de Docker. Esto puede resultar rápidamente en un error de no dejar espacio en el dispositivo. Los pasos son como delineado aquí:

1. Para verificar todas las imágenes en el contenedor de Docker, podemos usar el comando de imágenes de Docker (docker images), de la siguiente manera:

   $ docker images

2. Para eliminar una imagen, podemos llamar al siguiente comando:

$ docker rmi 48b5124b2768

3. En el caso de las imágenes, el proceso de limpieza automática es un poco más complejo. Las imágenes no tienen estados, por lo que no podemos pedirles que se eliminen cuando no se usan. Una estrategia común sería configurar un trabajo de limpieza de cron, que elimina todas las imágenes antiguas y no utilizadas. Podríamos hacer esto usando el siguiente comando:

   $ docker image prune

   Información: Si tenemos contenedores que usan volúmenes, entonces, además de imágenes y contenedores, vale la pena pensar en limpiar volúmenes. La forma más fácil de hacer esto es usar el comando d**ocker volume prune.**

**Consejo**: Use el comando docker system prune para eliminar todos los contenedores, imágenes y redes no utilizados. Además, puede agregar el parámetro –volumes para limpiar volúmenes.

**Descripción general de los comandos de Docker**

Todos los comandos de Docker se pueden encontrar ejecutando el siguiente comando de ayuda:

$ docker help

Computación Paralela y Distribuida ![ref3]

**Departamento Académico de Ingeniería C8286-Computación Paralela y Distribuida** 

Para ver todas las opciones de cualquier comando de Docker en particular, podemos usar la ayuda de docker help <comando>, como en el siguiente ejemplo:

$ docker help run

También hay una muy buena explicación de todos los comandos de Docker en la página oficial de Docker en https://docs.docker.com/engine/reference/commandline/docker/.

Vale la pena leerlo, o al menos echarle un vistazo. **Preguntas**

1. ¿Cuál es la principal diferencia entre la contenedorización (como con Docker) y la

virtualización (como con VirtualBox)?

**La principal diferencia entre la contenedorización (como con Docker) y la virtualización (como con VirtualBox) es que la contenedorización comparte el mismo sistema operativo del host, lo que la hace más liviana y eficiente, mientras que la virtualización crea un sistema operativo completo para cada máquina virtual, lo que puede ser más pesado en términos de recursos.**

2. ¿Cuáles son los beneficios de proporcionar una aplicación como imagen de Docker? Nombra al menos dos.

   **Los beneficios de proporcionar una aplicación como imagen de Docker incluyen la portabilidad, ya que la imagen contiene todo lo necesario para ejecutar la aplicación en cualquier entorno de Docker, y la consistencia, ya que garantiza que la aplicación se ejecute de la misma manera en diferentes entornos**.

3. ¿Se puede ejecutar el demonio Docker de forma nativa en Windows y Linux? **Sí, el demonio Docker puede ejecutarse de forma nativa en Windows y Linux**
3. ¿Cuál es la diferencia entre una imagen de Docker y un contenedor de Docker?

   **La diferencia entre una imagen de Docker y un contenedor de Docker es que una imagen es un paquete estático que contiene el código, las bibliotecas y las dependencias necesarias para ejecutar una aplicación, mientras que un contenedor es una instancia en ejecución de una imagen.**

5. ¿Qué significa decir que las imágenes de Docker tienen capas?

**Decir que las imágenes de Docker tienen capas significa que están compuestas por capas que representan los cambios realizados en la imagen, lo que permite la reutilización de capas comunes entre imágenes y la optimización del almacenamiento.**

6. ¿Cuáles son dos métodos para crear una imagen de Docker?

**Dos métodos para crear una imagen de Docker son mediante un Dockerfile, que es un archivo de texto que contiene los pasos para construir la imagen, y mediante la modificación de un contenedor existente y la creación de una nueva imagen a partir de ese contenedor modificado.**

7. ¿Qué comando se utiliza para crear una imagen de Docker a partir de un Dockerfile?

**El comando utilizado para crear una imagen de Docker a partir de un Dockerfile es docker build**.

8. ¿Qué comando se utiliza para ejecutar un contenedor Docker desde una imagen de Docker?

   **El comando utilizado para ejecutar un contenedor Docker desde una imagen de Docker es docker run**

9. En la terminología de Docker, ¿qué significa publicar un puerto?

**En la terminología de Docker, publicar un puerto significa exponer un puerto del contenedor al host o a la red externa, permitiendo así el acceso a servicios dentro del contenedor.**

10. ¿Qué es un volumen Docker?

**Un volumen Docker es un mecanismo para persistir datos generados por contenedores, permitiendo el almacenamiento de datos fuera del sistema de archivos del contenedor y facilitando el intercambio de datos entre contenedores y el host.**

11. ¿Qué comando se utiliza para enumerar solo los ID de todos los contenedores?

**El comando utilizado para enumerar solo los ID de todos los contenedores es docker ps -q**

**Ejercicios**

1. Ejecute CouchDB como contenedor Docker y publique su puerto de la siguiente manera: Puede usar el comando de búsqueda de Docker para encontrar la imagen de CouchDB.

   Computación Paralela y Distribuida ![ref3]

   **Departamento Académico de Ingeniería C8286-Computación Paralela y Distribuida** 

- Ejecute el contenedor.
- Publicar el puerto CouchDB.
- Abra el navegador y verifique que CouchDB esté disponible.

Para ejecutar CouchDB como un contenedor Docker y publicar su puerto, puedes seguir estos pasos:

Busca la imagen de CouchDB usando el comando de búsqueda de Docker. Ejecuta el contenedor, publicando el puerto de CouchDB.

Abre el navegador y verifica que CouchDB esté disponible.

2. Cree una imagen de Docker con un servicio REST, respondiendo Hola Mundo a localhost:8080/hello. Utilice cualquier lenguaje y frameworks que prefiera. Estos son los pasos que debes seguir:
- Cree una aplicación de servicio web.
- Crea un Dockerfile para instalar dependencias y bibliotecas.
- Construye la imagen.
- Ejecute el contenedor que está publicando el puerto.
  - Compruebe que se esté ejecutando correctamente utilizando el navegador (o curl).

Para crear una imagen de Docker con un servicio REST que responda "Hola Mundo" en localhost:8080/hello, puedes seguir estos pasos:

Crea una aplicación de servicio web.

Crea un Dockerfile para instalar dependencias y bibliotecas.

Construye la imagen.

Ejecuta el contenedor que publica el puerto.

Comprueba que esté funcionando correctamente usando el navegador (o curl).

3. ¿Cómo crearía un Dockerfile que hereda de la versión 22.04 de Ubuntu y que instala ping y ejecuta ping cuando se inicia un contenedor? La dirección predeterminada utilizada para hacer ping debe ser 127.0.0.1.

**FROM ubuntu:22.04**

**RUN apt-get update && apt-get install -y iputils-ping CMD ["ping", "127.0.0.1"]**

4. ¿Cómo crearías una nueva imagen de contenedor que use alpine:latest como imagen base e instale curl encima? Nombra la nueva imagen como my-alpine:1.0.

   **FROM alpine:latest**

   **RUN apk --no-cache add curl**

5. Cree un Dockerfile que utilice varios pasos para crear una imagen de una aplicación de algoritmos (el que desees de tamaño mínimo), escrita en C, Go, Java, C++. 6. ¿Cómo crearía un volumen de datos con un nombre como mis-productos utilizando el controlador predeterminado?

   Para crear un Dockerfile que utilice varios pasos para crear una imagen de una aplicación de algoritmos escrita en C, Go, Java, C++, puedes seguir un enfoque similar al siguiente ejemplo (sustituyendo los comandos según el lenguaje de programación y las bibliotecas que necesites):

- **Paso 1: Compilar la aplicación en C FROM gcc as builder**

  **WORKDIR /app**

  **COPY . /app**

  **RUN gcc -o myapp main.c**

- **Paso 2: Utilizar una imagen base mínima FROM alpine**

  **WORKDIR /app**

  **COPY --from=builder /app/myapp /app CMD ["./myapp"]**

  6\.Para crear un volumen de datos con el nombre "mis-productos" utilizando el controlador predeterminado, puedes ejecutar el siguiente comando:

  **docker volume create mis-productos**

7. ¿Cómo ejecutaría un contenedor usando la imagen de Alpine y montaría el volumen de mis-productos en modo de solo lectura en la carpeta del contenedor /data?

   **docker run -v mis-productos:/data:ro alpine**

8. ¿Cómo ubicaría la carpeta asociada con el volumen mis-productos y navegaría hasta ella? Además, ¿cómo crearías un archivo, muestra.txt, con algún contenido?

   Para ubicar la carpeta asociada con el volumen "mis-productos" y navegar hasta ella, puedes utilizar el siguiente comando:

   **docker volume inspect mis-productos**

   Y para crear un archivo llamado "muestra.txt" con algún contenido dentro de la carpeta del volumen, puedes ejecutar los siguientes comandos:

   **docker run -v mis-productos:/mnt alpine sh -c "echo 'Hola, mundo' > /mnt/muestra.txt"**

9. ¿Cómo ejecutaría otro contenedor Alpine donde monte el volumen my-productos en la carpeta /app-data, en modo lectura/escritura? Dentro de este contenedor,

   **docker run -v mis-productos:/app-data -it alpine**

   Esto montará el volumen "mis-productos" en la carpeta /app-data del contenedor Alpine con permisos de lectura y escritura.

   10 (investiga). ¿Cuándo y por qué depurarías el código línea por línea cuando se ejecuta dentro de un contenedor?. Muestra un ejemplo.

   Depurar el código línea por línea dentro de un contenedor puede ser útil cuando se necesita identificar y solucionar problemas específicos que solo ocurren en el entorno del contenedor. Por ejemplo, si el código interactúa con recursos del sistema operativo o depende de configuraciones específicas del contenedor, depurar línea por línea puede ayudar a entender el comportamiento del código en ese contexto particular.

   Un ejemplo simple sería depurar una aplicación de Python dentro de un contenedor. Supongamos que tenemos un script de Python llamado "app.py" que no se comporta como se espera dentro del contenedor. Podríamos ejecutar el contenedor de la siguiente manera para depurar el código línea por línea:

   **docker run -it --rm --name my-python-debug -v $(pwd):/app -w /app python:3.8-alpine sh**

   Una vez dentro del contenedor, podríamos ejecutar el script línea por línea utilizando el depurador de Python, por ejemplo

**python -m pdb app.py**

Esto nos permitiría inspeccionar el estado del programa y ejecutarlo línea por línea para identificar cualquier problema.

Computación Paralela y Distribuida

[ref1]: Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.001.png
[ref2]: Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.023.png
[ref3]: Aspose.Words.872c9c36-cdde-447d-864a-ac7e71fed549.024.png
