﻿**Departamento Académico de Ingeniería ![ref1]**

**C8280 -Comunicación de Datos y Redes** 

**Actividad 0: Verificación del funcionamiento de Docker, Docker, Desktop, Minikube, Kind**

.

**Objetivos**

1. Comprender la virtualización y la contenerización: Entender las diferencias fundamentales entre la virtualización tradicional y la contenerización, y cómo Docker revoluciona el desarrollo y la implementación de aplicaciones mediante la creación de entornos ligeros y portátiles.
1. Familiarización con Docker y Docker Desktop: Aprender a instalar y configurar Docker y Docker Desktop en Linux y cómo pueden facilitar el desarrollo y la distribución de aplicaciones.
1. Explorar Kubernetes con Minikube y Kind: Entender los conceptos básicos de Kubernetes como sistema de orquestación de contenedores, y aprender a utilizar Minikube y Kind para crear y gestionar clústeres de Kubernetes en un entorno local. Esto incluye comprender la arquitectura de Kubernetes, los objetos de Kubernetes (pods, servicios, despliegues, etc.) y cómo se pueden manejar a través de estas herramientas.

**Prueba de Docker Engine**

1. Descarga e instale Docker Desktop: https://docs.docker.com/desktop/install/ubuntu/
1. Ahora que ha instalado Docker Desktop con éxito, probémoslo. Comenzaremos ejecutando un contenedor Docker simple directamente desde la línea de comando. Abra una ventana de Terminal y ejecute el siguiente comando:

$ docker version![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.002.jpeg)


![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.003.jpeg)

3. Para ver si puede ejecutar contenedores, ingrese el siguiente comando en la ventana de Terminal y presione Enter:

$ docker container run hello-world

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.004.jpeg)

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.005.jpeg)

Si lee atentamente el resultado anterior, habrá notado que Docker no encontró una imagen llamada hello-world:latest y, por lo tanto, decidió descargarla desde un registro de imágenes de Docker. Una vez descargado, Docker Engine creó un contenedor a partir de la imagen y lo ejecutó. La aplicación se ejecuta dentro del contenedor y luego genera todo el texto, comenzando con Hello from Docker!

Esta es una prueba de que Docker está instalado y funcionando correctamente en su máquina.

4. Probemos con otra imagen de prueba divertida que normalmente se usa para verificar la instalación de Docker. Ejecute el siguiente comando:

   $ docker container run rancher/cowsay Hello

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.006.jpeg)

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.007.jpeg)

Genial: hemos confirmado que Docker Engine funciona en nuestra computadora local. Ahora, asegurémonos de que lo mismo ocurre con Docker Desktop.

Observación : para crear el grupo de Docker y agregar su usuario se requiere los siguientes pasos:

1. Crear el grupo docker: sudo groupadd docker
1. Agregar tu usuario a tu grupo docker: sudo usermod -aG docker $USER También revisar: https://docs.docker.com/engine/security/rootless/
1. Cierre sesión y vuelva a iniciarla para que se reevalúe su permanencia en el grupo.
1. También puede ejecutar el siguiente comando para activar los cambios en los grupos: newgrp docker
5. Verifica que puedes correr comandos docker sin usar sudo.

**Habilitar Kubernetes en Docker Desktop**

**Instalación de Docker Desktop: https://docs.docker.com/desktop/install/linux-install/** Docker Desktop viene con soporte integrado para Kubernetes.

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.008.png)

**¿Qué es Kubernetes?**

Kubernetes es una poderosa plataforma para automatizar la implementación, el escalado y la gestión de aplicaciones en contenedores. Ya seas desarrollador, ingeniero de DevOps o administrador de sistemas, Kubernetes proporciona las herramientas y abstracciones que necesita para administrar sus contenedores y aplicaciones de manera escalable y eficiente. Este soporte está desactivado de forma predeterminada. Pero no te preocupes: es muy fácil de activar:

1. Abra el panel de **Docker Desktop.**

Comunicación de Datos y Redes ![ref1]

**Departamento Académico de Ingeniería C8280 -Comunicación de Datos y Redes** 

2. En la esquina superior izquierda, seleccione el ícono de la rueda dentada. Esto abrirá la página de configuración (setting).

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.009.jpeg)

3. En el lado izquierdo, seleccione la pestaña Kubernetes y luego marque la casilla Enable Kubernetes

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.010.jpeg)

4. Haga clic en el botón Apply & restart.

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.011.jpeg)Ahora, deberá tener paciencia ya que Docker está descargando toda la infraestructura de soporte y luego inicia Kubernetes.

Una vez que Docker se haya reiniciado, estará listo para usar Kubernetes.

**Probando minikube y kubectl**

Descarga e instala y minikube https://minikube.sigs.k8s.io/docs/start/ y kubectl https://kubernetes.io/docs/tasks/tools/install-kubectl-linux/ y la opción Install using native package management

Ahora escribe minikube start para iniciar el cluster por defecto . La primera vez que haga esto, llevará un tiempo ya que minikube necesita descargar todos los binarios de Kubernetes. Cuando termine, la última línea del resultado en su pantalla debería ser algo como esto:

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.012.png)

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.013.jpeg)

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.014.jpeg)

Empecemos. Siga estos pasos cuidadosamente:

1. Intentemos acceder a nuestro clúster usando kubectl. Primero, debemos asegurarnos de

tener seleccionado el contexto correcto para kubectl. Si anteriormente instaló Docker Desktop y ahora minikube, puede usar el siguiente comando:

$ kubectl config get-contexts

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.015.png)

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.016.png)

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.017.png)El asterisco al lado del contexto llamado minikube nos dice que este es el contexto actual. Así, al usar kubectl, trabajaremos con el nuevo cluster creado por minikube.

2. Ahora veamos cuántos nodos tiene nuestro cluster con este comando: $kubectl get nodes

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.018.png)

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.019.png)

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.020.png)

Deberías obtener algo similar a esto. Tenga en cuenta que la versión mostrada podría diferir en su caso:

Comunicación de Datos y Redes ![ref1]

**Departamento Académico de Ingeniería C8280 -Comunicación de Datos y Redes** 

Aquí tenemos un clúster de un solo nodo. El papel del nodo es el del plano de control, lo que significa que es un nodo maestro. Un clúster de Kubernetes típico consta de unos pocos nodos maestros y muchos nodos trabajadores. La versión de Kubernetes con la que estamos trabajando aquí es la v1.28.3.

3. Ahora, intentemos ejecutar algo en este clúster. Usaremos Nginx, un servidor web popular para esto. Utiliza el archivo .yaml, que acompaña a la actividad que vamos a utilizar para esta prueba:

Abra una nueva ventana de Terminal y crea un pod que ejecute Nginx con el siguiente comando:

$ kubectl apply -f nginx.yaml

kubectl apply -f /home/alumno/Descargas/nginx.yaml

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.021.png)

Deberías ver este resultado: pod/nginx created![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.022.png)

4. Podemos verificar si el pod se está ejecutando con kubectl: $ kubectl get pods

   Deberíamos ver esto:

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.023.png)

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.024.png)

Esto indica que tenemos 1 pod con Nginx ejecutándose y que se ha reiniciado 0 veces.

5. Para acceder al servidor Nginx, necesitamos exponer la aplicación que se ejecuta en el pod con el siguiente comando:

   $ kubectl expose pod nginx --type=NodePort --port=80

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.025.png)

Esta es la única forma en que podemos acceder a Nginx desde nuestra computadora portátil, por ejemplo, a través de un navegador. Con el comando anterior, estamos creando un servicio de Kubernetes, como se indica en el resultado generado para el comando:

service/nginx exposed

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.026.png)

6. Podemos usar kubectl para enumerar todos los servicios definidos en nuestro clúster: $ kubectl get services

   Comunicación de Datos y Redes

**Departamento Académico de Ingeniería ![ref1]**

**C8280 -Comunicación de Datos y Redes** 

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.027.png)

RESULTADO MIO

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.028.png)

En el resultado anterior, podemos ver el segundo servicio llamado Nginx, que acabamos de crear. El servicio es del tipo NodePort; El puerto 80 del pod se había asignado al puerto 30432 del nodo del clúster de nuestro clúster de Kubernetes en minikube.

7. Ahora, podemos usar minikube para crear un túnel hacia nuestro clúster y abrir un navegador con la URL correcta para acceder al servidor web Nginx. Utilice este comando:

   $ minikube service nginx

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.029.png)

El resultado en su ventana de Terminal será el siguiente:

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.030.png)

RESULTADO MIO


![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.031.jpeg)

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.032.jpeg)

El resultado anterior muestra que minikube creó un túnel para el servicio nginx que escucha en el puerto del nodo 30432 que está en nuestra computadora portátil.

Hemos ejecutado y accedido con éxito a un servidor web Nginx en nuestro pequeño clúster de Kubernetes de un solo nodo en minikube! Una vez que hayas terminado de jugar, es hora de limpiar:

- Detenga el túnel hacia el clúster presionando Ctrl + C dentro de la ventana de Terminal.
- Elimine el servicio nginx y el pod en el clúster: $ kubectl delete service nginx $

kubectl delete pod nginx

- Detenga el clúster con el siguiente comando: minikube stop
- Deberías ver esto:

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.033.png)

RESULTADO MIO

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.034.png)

**Ejercicios**

A veces, probar con un clúster de un solo nodo no es suficiente. minikube lo resuelve. Siga estas instrucciones para crear un verdadero clúster de Kubernetes de múltiples nodos en minikube:

1. Si queremos trabajar con un clúster que consta de varios nodos en minikube, podemos usar este comando:

$ minikube start --nodes 3 –p demo RESULTADO MIO

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.035.jpeg)

El comando anterior crea un clúster con tres nodos y lo llama demo.

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.036.jpeg)

2. Utilice kubectl para enumerar todos los nodos de su clúster: $ kubectl get

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.037.png)

Tenemos un clúster de 3 nodos donde el nodo **demo** es un nodo maestro y los dos nodos restantes son nodos de trabajo.

3. No vamos a continuar con este ejemplo aquí, así que use el siguiente comando para detener el clúster:

   $ minikube stop -p demo

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.038.png)

4. Elimine todos los clústeres de su sistema con este comando: $ minikube delete --all

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.039.png)

Esto eliminará el clúster predeterminado (llamado minikube) y el clúster **demo** en nuestro caso.

Con esto, pasaremos a la siguiente herramienta interesante y útil a la hora de trabajar con contenedores y Kubernetes. Debería tenerlo instalado y disponible en la computadora de su trabajo.

**Kind**

Kind (https://kind.sigs.k8s.io/docs/user/quick-start) es otra herramienta popular que se puede utilizar para ejecutar un clúster de Kubernetes de múltiples nodos localmente en su máquina. Es muy fácil de instalar y usar.

Vamos:

1. En una máquina Linux, puedes usar el siguiente script para instalar Kind desde sus

archivos binarios:

curl -Lo ./kind https://kind.sigs.k8s.io/dl/v0.22.0/kind-linux-amd64

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.040.png)

$chmod +x ./kind

$sudo mv ./kind /usr/local/bin/kind

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.041.png)

2. Una vez instalado Kind, pruébelo con el siguiente comando: $ kind version

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.042.png)

RESULTADO MIO

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.043.png)

3. Ahora, intente crear un clúster de Kubernetes simple que consta de un nodo maestro y dos nodos trabajadores. Utilice este comando para lograr esto:

   $ kind create cluster

   Después de un tiempo, deberías ver este resultado:

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.044.png)

RESULTADO MIO

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.045.png)

4. Para verificar que se ha creado un clúster, utilice este comando: $ kind get clusters

   El resultado anterior muestra que hay exactamente un clúster llamado **kind,** que es el nombre predeterminado.

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.046.png)

RESULTADO MIO

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.047.png)

5. Podemos crear un clúster adicional con un nombre diferente usando el parámetro -- **name,** así:

   $ kind create cluster --name demo

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.048.png)

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.049.png)

6. Al enumerar los clústeres se mostrará esto: $ kind get clusters

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.050.png)

Y esto funciona como se esperaba.

Ahora que hemos usado kind para crear dos clústeres de muestra, usemos kubectl para jugar con uno de los clústeres y ejecutar la primera aplicación en él. Usaremos Nginx para esto, similar a lo que hicimos con minikube:

Ahora podemos usar kubectl para acceder y trabajar con los clústeres que acabamos de crear. Mientras creaba un clúster, Kind también actualizó el archivo de configuración de nuestro kubectl. Podemos verificar esto con el siguiente comando:

$ kubectl config get-contexts

Debería producir el siguiente resultado:

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.051.png)

RESULTADO MIO


![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.052.png)

Puede ver que los clústeres **kind** y de **demo** son parte de la lista de clústeres conocidos y que el clúster de demo es el contexto actual para kubectl.

2. Utilice el siguiente comando para convertir el clúster de demo en su clúster actual si el asterisco indica que hay otro clúster actual:

   $ kubectl config use-context kind-demo

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.053.png)

3. Enumeremos todos los nodos del clúster de muestra:

$ kubectl get nodes

La salida debería ser así:

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.054.png)

RESULTADO MIO

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.055.png)

4. Ahora, intentemos ejecutar el primer contenedor en este clúster. Usaremos nuestro servidor web Nginx de confianza, como hicimos antes. Utilice el siguiente comando para ejecutarlo:

   $ kubectl apply -f nginx.yaml

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.056.png)

El resultado debería ser el siguiente:

pod/nginx created

5. Para acceder al servidor Nginx, necesitamos realizar el reenvío de puertos usando kubectl. Utilice este comando para hacerlo:

   Revisa: kubectl describe pod nginx, https://www.kristhecodingunicorn.com/post/kubernetes port-forwarding-cleanup-of-orphaned-ports/

   $ kubectl port-forward nginx 8080 80 (puedes usar otros puertos)

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.057.png)

Abra una nueva pestaña del navegador y navegue hasta http://localhost:8080; Deberías ver la pantalla de bienvenida de Nginx

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.058.jpeg)

Una vez que hayas terminado de jugar con Nginx, usa este comando para eliminar el pod del clúster:

$ kubectl delete -f nginx.yaml

kubectl delete -f /home/alumno/Descargas/nginx.yaml


![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.059.png)

Antes de continuar, limpiemos y eliminemos los dos clústeres que acabamos de crear:

$ kind delete cluster --name kind $ kind delete cluster --name demo

![](Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.060.png)

Con esto, hemos instalado todas las herramientas que necesitaremos para trabajar exitosamente con contenedores en nuestra máquina local.

**Preguntas**

Con base en lo que se cubrió en esta actividad, responda las siguientes preguntas:

1. En tus propias palabras, usando analogías, explica qué es un contenedor.

**Un contenedor es como una caja fuerte que contiene todo lo que un programa necesita para funcionar, como archivos, librerías y configuraciones, pero aislado del resto del sistema, como un envase que guarda todos los ingredientes de una comida por separado, listos para ser usados cuando se necesiten.**

2. ¿Por qué se considera que los contenedores cambian las reglas del juego en IT?

Mencione tres o cuatro razones.

**Los contenedores cambian las reglas del juego en IT porque son más rápidos, portátiles y eficientes. Permiten un desarrollo más ágil, facilitan la gestión de aplicaciones y hacen que la infraestructura sea más escalable.**

3. ¿Qué significa cuando afirmamos que, si un contenedor se ejecuta en una plataforma determinada, entonces se ejecutará en cualquier lugar? Mencione dos o tres razones por las que esto es cierto.

**Cuando decimos que un contenedor se ejecuta en una plataforma determinada, significa que funcionará en cualquier lugar debido a su portabilidad y consistencia. Esto es cierto porque los contenedores encapsulan todo lo que necesitan para ejecutarse, independientemente del entorno.**

4. ¿Es verdadera o falsa la siguiente afirmación: los contenedores Docker solo son útiles para aplicaciones modernas y totalmente nuevas basadas en microservicios? Por favor justifique su respuesta.

**Falsa. Los contenedores Docker no solo son útiles para aplicaciones modernas y nuevas basadas en microservicios, también pueden beneficiar a aplicaciones existentes al facilitar su despliegue y gestión. Son flexibles y pueden adaptarse a diferentes tipos de aplicaciones**

5. ¿Por qué nos importaría instalar y usar un administrador de paquetes en nuestra computadora local?

**Nos importaría instalar y usar un administrador de paquetes en nuestra computadora local porque nos permite gestionar y actualizar fácilmente software, librerías y herramientas, simplificando la instalación y mantenimiento de programas.**

6. ¿Con Docker Desktop, puede desarrollar y ejecutar contenedores de Linux? **Sí, con Docker Desktop puedes desarrollar y ejecutar contenedores de Linux en sistemas Windows y macOS**.
6. ¿Por qué son esenciales buenas habilidades de programación (como Bash o PowerShell) para el uso productivo de los contenedores?

   **Las buenas habilidades de programación son esenciales para el uso**

   **productivo de los contenedores porque permiten automatizar tareas, crear scripts y realizar operaciones avanzadas en el entorno de contenedores.**

8. Nombra tres o cuatro distribuciones de Linux en las que Docker esté certificado para ejecutarse.

**Algunas distribuciones de Linux en las que Docker está certificado para ejecutarse son Ubuntu, CentOS, Red Hat Enterprise Linux y SUSE Linux Enterprise**

9. Instalaste minikube en tu sistema. ¿Para qué tipo de tareas utilizarás esta herramienta?

**Al instalar Minikube, podré utilizar esta herramienta para crear y**

**gestionar entornos de Kubernetes locales, lo que me permitirá probar y desarrollar aplicaciones en un entorno similar al de producción, pero en mi propia computadora.**

Comunicación de Datos y Redes

[ref1]: Aspose.Words.d5c2a64f-fa52-4be5-8e23-65da5dd7e291.001.png
