﻿**Departamento Académico de Ingeniería C8286-Computación Paralela y Distribuida**

**Evaluación: Sobre la línea de comandos**

**Objetivos**

Linux, siendo un sistema operativo tipo Unix, es ampliamente utilizado en servidores, supercomputadoras y sistemas distribuidos. Conocer la línea de comandos de Linux permite comprender y manipular el sistema operativo subyacente en el que se ejecutan sus aplicaciones concurrentes y distribuidas, ofreciendo una comprensión profunda de su entorno de ejecución.

La línea de comandos de Linux es una herramienta poderosa para la automatización de tareas repetitivas y la gestión eficiente de recursos del sistema. Podemos aprender a escribir scripts para automatizar la compilación y ejecución de sus programas, la gestión de procesos, el monitoreo del uso de recursos y la implementación de sistemas. Esta habilidad es invaluable en entornos de computación distribuida, donde la gestión manual de múltiples nodos y servicios puede ser tediosa y propensa a errores.

Muchas herramientas esenciales para el desarrollo, la prueba y la depuración de software en computación concurrente y distribuida son accesibles a través de la línea de comandos. Esto incluye herramientas para control de versiones (como **git**), empaquetado y despliegue de software (como **make** y **docker**), y monitoreo de rendimiento y recursos (como **top**, **vmstat**, y **netstat**). Familiarizarse con estas herramientas es esencial para el desarrollo de software eficiente.

El conocimiento de la línea de comandos es fundamental para interactuar con servicios en la nube y sistemas distribuidos, muchos de los cuales ofrecen interfaces basadas en CLI (Command Line Interface) para su gestión y configuración. Aprenderemos a desplegar, configurar y monitorear aplicaciones distribuidas en entornos cloud, utilizando la línea de comandos.

La línea de comandos promueve un entendimiento más profundo de cómo funcionan los computadores y las redes, alentando a todos a pensar y resolver problemas de manera algorítmica. Esta forma de pensamiento es transferible a muchos otros ámbitos de la informática y la ingeniería de software.

**Instrucciones de Entrega:**

- Realiza todos los pasos de cada sección en la terminal, capturando capturas de pantalla o copiando el texto de la terminal que demuestre la ejecución de la sección Learning the Shell de la página: https://linuxcommand.org/lc3\_learning\_the\_shell.php
- Crea un documento en markdown que incluya una breve explicación de cada tarea, junto con las capturas de pantalla o texto correspondiente.
- Subir el documento final a tu repositorio personal hasta el día 13 de abril (23:59).

Learning the Shell [What is "the Shell"?](https://linuxcommand.org/lc3_lts0010.php)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.001.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.002.png)

[Navigation](https://linuxcommand.org/lc3_lts0020.php)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.003.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.004.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.005.jpeg)

**Atajos**

**Si escribes cd seguido de nada, cambiará el directorio de trabajo a tu directorio de inicio.**

**Si escribes cd ~user\_name, cambiará el directorio de trabajo al directorio de inicio del usuario especificado.**

**Escribir cd - cambiará el directorio de trabajo al directorio anterior.**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.006.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.007.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.008.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.009.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.010.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.011.jpeg)

**L[ooking Around**](https://linuxcommand.org/lc3_lts0030.php)**

**Listar los archivos en el directorio de trabajo:**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.012.png)

**Listar los archivos en el directorio /bin (o cualquier otro directorio que especifiquemos):**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.013.jpeg)

**Listar los archivos en el directorio de trabajo en formato largo:**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.014.jpeg)

**Listar los archivos en los directorios /etc y /bin en formato largo:**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.015.jpeg)

**Listar todos los archivos (incluso los que empiezan con un punto, que normalmente están ocultos) en el directorio padre del directorio de trabajo en formato largo:**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.016.jpeg)

**less (ver archivos de texto) less archivo.txt**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.017.jpeg)

**file**

**file nombre\_del\_archivo**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.018.png)

[**A Guided Tour**](https://linuxcommand.org/lc3_lts0040.php)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.019.jpeg)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.020.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.021.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.022.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.023.jpeg)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.024.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.025.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.026.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.027.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.028.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.029.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.030.jpeg)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.031.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.032.jpeg)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.033.jpeg)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.034.jpeg)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.035.png)

[**Manipulating Files**](https://linuxcommand.org/lc3_lts0050.php)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.036.jpeg)

**Copiar archivos:**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.037.png)

**Mover archivos:**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.038.png)

**Renombrar un archivo:**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.039.png)

**Eliminar archivos y directorios:**

**Eliminar un archivo**:

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.040.png)

**Eliminar un directorio y su contenido:**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.041.png)

**mkdir (Crear directorios)**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.042.jpeg)

**Uso de comandos con comodines:**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.043.png)

[**Working with Commands**](https://linuxcommand.org/lc3_lts0060.php)

**type**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.044.png)

**which**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.045.png)

**help**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.046.jpeg)

**--help**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.047.jpeg)

**man**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.048.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.049.jpeg)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.050.jpeg)

**i[/O Redirection ](https://linuxcommand.org/lc3_lts0070.php)salida estandar**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.051.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.052.png)

**entrada estandar**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.053.jpeg)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.054.png)

**gasolinas**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.055.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.056.jpeg)

**ls -lt | [head M](https://linuxcommand.org/lc3_man_pages/head1.html)uestra los 10 archivos más nuevos en el directorio actual.**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.057.png)

[**du](https://linuxcommand.org/lc3_man_pages/du1.html) **| sort -nr Muestra una lista de directorios y cómo mucho espacio que**

**consumen, ordenados de la más grande para el más pequeño.**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.058.jpeg)

[**find ](https://linuxcommand.org/lc3_man_pages/find1.html)**. -type f -print | wc[ -l ](https://linuxcommand.org/lc3_man_pages/wc1.html)Muestra el número total de archivos en el**

**actual directorio de trabajo y todo su subdirectorios.**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.059.png)

**filtros**

[**sort O](https://linuxcommand.org/lc3_man_pages/sort1.html)**rdena la entrada estándar y luego sale resultado ordenado en la salida**

**estándar.**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.060.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.061.png)

[**uniq ](https://linuxcommand.org/lc3_man_pages/uniq1.html)**Dado un flujo ordenado de datos de entrada estándar, elimina líneas**

**duplicadas de datos (es decir, se asegura de que cada línea es únicos).**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.062.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.063.png)

[**grep E](https://linuxcommand.org/lc3_man_pages/grep1.html)**xamina cada línea de datos que recibe de entradas y salidas estándar en**

**cada línea que contiene un patrón especificado de caracteres.**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.064.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.065.png)

[**fmt ](https://linuxcommand.org/lc3_man_pages/fmt1.html)**Lee el texto de la entrada estándar, luego Salidas en formateadas en el tipo**

**salida.**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.066.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.067.png)

[**pr ](https://linuxcommand.org/lc3_man_pages/pr1.html)**Toma la entrada de texto de la entrada estándar y divide los datos en páginas**

**con rupturas de página, encabezados y pies en preparación para impresión.**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.068.png)

[**head ](https://linuxcommand.org/lc3_man_pages/head1.html)**Salde las primeras líneas de su entrada. Util para conseguir la cabecera de**

**un archivo.**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.069.jpeg)

[**tail S](https://linuxcommand.org/lc3_man_pages/tail1.html)**alidas las últimas líneas de su entrada. Util para cosas como sacar más**

**entradas recientes de un archivo de registro.**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.070.png)

[**tr ](https://linuxcommand.org/lc3_man_pages/tr1.html)**Traducir caracteres. Se puede acostumbrar a realizar tareas como mayúsculas**

**conversiones o cambio de línea de terminación caracteres de un tipo a otro (para ejemplo, convirtiendo archivos de texto de DOS en Unix archivos de texto de estilo).**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.071.png)

[**sed ](https://linuxcommand.org/lc3_man_pages/sed1.html)**Editor de Stream. Puede actuar más sofisticadas traducciones de texto que**

**tr.**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.072.png)

**ste comando buscará todas las ocurrencias de la palabra "documento" en el**

**archivo archivo.txt y las reemplazará con la palabra "salida". La salida se mostrará en la terminal.**

[**awk](https://linuxcommand.org/lc3_man_pages/awk1.html) **Todo un lenguaje de programación diseñado para la construcción de filtros.**

**Extremadamente poderosos.**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.073.png)

**Supongamos que tienes un archivo CSV llamado datos.csv con tres columnas:**

**nombre, edad y ciudad. Puedes usar awk para imprimir solo la columna de nombres del archivo datos.csv**

**Este comando indica a awk que utilice la coma como delimitador de campos (-F**

**',') y que imprima el primer campo de cada fila ({print $1}), que en este caso es la columna de nombres.**

**Realización de tareas con oleoductos**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.074.png)

[**Expansion**](https://linuxcommand.org/lc3_lts0080.php)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.075.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.076.png)

**Pathname Expansion**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.077.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.078.png)

**Tilde Expansion**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.079.png)

**Expansión aritmética**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.080.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.081.png)

**Presionan la expansión**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.082.jpeg)

**Expansión de parámetros**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.083.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.084.jpeg)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.085.png)

**Substitución de mando**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.086.jpeg)

**Citando**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.087.png)

**Dobles citas**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.088.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.089.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.090.jpeg)

**Citas únicas**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.091.png)

**Personajes fugados**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.092.png)

**Más trucos de reacción**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.093.jpeg)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.094.jpeg)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.095.png)

[Permissions](https://linuxcommand.org/lc3_lts0090.php)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.096.png)

**777 (rwxrwxwx)** No hay restricciones a los permisos. Cualquiera puede hacer cualquier cosa. Generalmente no es un ajuste deseable.

**755 (rwxr-xr-x)** El propietario del archivo puede Leer, escribir y ejecutar el archivo. Todos los demás puede leer y ejecutar el archivo. Este entorno es común para los programas que son utilizados por todos usuarios.

**700 (rwx------)** El propietario del archivo puede Leer, escribir y ejecutar el archivo. Nadie Si no, tiene derechos. Este entorno es útil. para programas que sólo el propietario puede usar y debe mantenerse en privado de los demás.

**666 (rw-rw-rw-)** Todos los usuarios pueden leer y escriba el archivo.

**644 (rw-r----)** El propietario puede leer y escribir un archivo, mientras que todos los demás sólo pueden Lee el archivo. Un ajuste común para los datos archivos que todo el mundo puede leer, pero sólo el el dueño puede cambiar.

**600 (row--------)** El propietario puede leer y escriba un archivo. Todos los demás no tienen derechos. Un ajuste común para los archivos de datos que el el dueño quiere mantenerte privado.

**Permisos de directorio**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.097.png)

**777 (rwxrwxwx)** No hay restricciones a los permisos. Cualquiera puede enumerar archivos, crear nuevos archivos en el directorio y borrar archivos en el directorio. Generalmente no es un bien. configuración.

**755 (rwxr-xr-x)** El propietario del directorio tiene acceso completo. Todos los demás pueden enumerar el directorio, pero no puede crear archivos ni borrar ellos. Este entorno es común para los directorios que desea compartir con otros usuarios.

**700 (rwx------)** El dueño del directorio tiene acceso completo. Nadie más tiene ningún derecho. Este entorno es útil para directorios que sólo el propietario puede usar y debe ser mantenido privado de otros.

**Convertirse en el superusario para un corto tiempo**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.098.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.099.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.100.png)

**Cambiar la propiedad de archivos**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.101.png)

**Cambio de la propiedad de grupos**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.102.png)

[Job Control](https://linuxcommand.org/lc3_lts0100.php)

**Un ejemplo práctico**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.103.png)

Poner un programa en el fondo

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.104.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.105.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.106.png)

**Lista de procesos de ejecución**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.107.png)

**Matar un proceso**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.108.jpeg)

**Un poco más sobre matar**

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.109.jpeg)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.110.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.111.png)

![](Aspose.Words.7bdb9ab7-b43b-4bdc-bb63-cc43ae988f96.112.png)
