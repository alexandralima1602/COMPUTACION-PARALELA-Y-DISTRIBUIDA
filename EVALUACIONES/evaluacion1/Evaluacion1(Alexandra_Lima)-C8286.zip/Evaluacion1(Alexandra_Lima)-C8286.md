﻿**Departamento Académico de Ingeniería ![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.001.png)C8286-Computación Paralela y Distribuida** 

**Evaluación: ps, grep, pipes linux, bash, awk**

**Objetivos**

- Aprender a listar y filtrar procesos activos en un sistema.
- Entender cómo identificar procesos por PID, usuario, uso de recursos y otros criterios.
- Utilizar **ps** para monitorear la salud y el rendimiento de aplicaciones paralelas y distribuidas.
- Aplicar **grep** para analizar logs de aplicaciones y sistemas, facilitando la depuración y el monitoreo.
- Utilizar pipes para crear cadenas de procesamiento de datos eficientes y scripts de análisis
- Aprender a escribir scripts de shell para automatizar tareas de administración y despliegue.
- Entender el control de flujo, manejo de variables, y funciones en Bash. • Desarrollar habilidades para la automatización de pruebas y despliegues en entornos de computación distribuida.
- Aprender a utilizar **awk** para el filtrado y transformación de datos complejos en scripts de shell.

**Entregable:**

Presenta el código completo y tus respuestas desarrollado en tu repositorio personal hasta el dia 16 de abril (8:00 PM). Recuerda presentar tus resultados en formato markdown y código si es que se ha realizado.

**El comando ps**

El comando **ps** en Linux y otros sistemas tipo Unix es una herramienta de línea de comandos utilizada para mostrar información sobre los procesos activos en un sistema. **ps** es el acrónimo de "process status" o estado del proceso. Proporciona una instantánea de los procesos corriendo en ese momento, incluyendo detalles como el ID del proceso (PID), el usuario propietario del proceso, el uso de CPU, el uso de memoria, el tiempo de ejecución, el comando que inició el proceso, entre otros.

En un curso de computación paralela, concurrente y distributiva, el comando **ps** puede ser aplicado de diversas maneras para facilitar la comprensión y gestión de los procesos y la ejecución de programas en estos entornos:

- **Monitoreo de procesos**: **ps** puede ser usado para enseñar cómo identificar y monitorear procesos individuales o grupos de procesos relacionados con aplicaciones paralelas y concurrentes.
- **Gestión de recursos**: Utilizando **ps** junto con otras herramientas, se puede enseñar a observar el uso de CPU y memoria, lo cual es crucial para la optimización de aplicaciones en entornos paralelos y distribuidos.
- **Depuración y diagnóstico**: En la computación paralela y concurrente, identificar procesos bloqueados, zombies o que consumen recursos excesivamente es fundamental para la depuración y el mantenimiento del rendimiento del sistema. **ps** permite identificar rápidamente tales procesos.
- **Automatización y scripting**: **ps** se puede usar en scripts de shell para automatizar

la supervisión y gestión de aplicaciones paralelas y distribuidas.

- **Estudio de casos**: Análisis de casos de estudio donde se requiere la identificación y gestión de procesos en sistemas de computación distribuida. Por ejemplo, cómo gestionar de manera eficiente múltiples instancias de un servicio web distribuido en un cluster de servidores.

**Ejercicios**

1. **Listar todos los procesos con detalles completos** ps -ef procesos con detalles completos

   ![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.002.png)

   ps aux

   ![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.003.png)

2. Buscar procesos específicos por nombre: ps -ef | grep **firefox**

   ![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.004.jpeg)

   ps aux | grep **apache**

   ![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.005.png)

3. Mostrar procesos en un árbol jerárquico (útil para ver relaciones padre-hijo en procesos concurrentes):

pstree

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.006.jpeg)

4. Mostrar procesos de un usuario específico:

ps -u root

Esto mostrará todos los procesos del usuario "root".

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.007.jpeg)

5. Escribe un script para verificar y reiniciar automáticamente un proceso si no está corriendo.

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.008.png)

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.009.png)

En estos scripts (recuerda son archivos Bash, terminan en .sh) verifica que efectivamente hacen lo que se indica:

**Monitoreo de procesos por uso excesivo de CPU**

#!/bin/bash

ps -eo pid,ppid,%cpu,cmd --sort=-%cpu | head -10 | while read pid ppid cpu cmd; do

if (( $(echo "$cpu > 80.0" | bc -l) )); then

echo "Proceso $pid ($cmd) está utilizando $cpu% de CPU." fi

done

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.010.png)

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.011.jpeg)

**Identificar procesos zombis y reportar**

#!/bin/bash

ps -eo stat,pid,cmd | grep "^Z" | while read stat pid cmd; do

echo "Proceso zombi detectado: PID=$pid CMD=$cmd"

done

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.012.png)

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.013.png)

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.014.png)

**Reiniciar automáticamente un servicio no está corriendo**

#!/bin/bash

SERVICE="apache2"

if ! ps -C $SERVICE > /dev/null; then

systemctl restart $SERVICE

echo "$SERVICE ha sido reiniciado." Fi

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.015.png)

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.016.png)


![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.017.png)

**Verificar la cantidad de instancias de un proceso y actuar si supera un umbral**

#!/bin/bash

PROCESS\_NAME="httpd"

MAX\_INSTANCES=10

count=$(ps -C $PROCESS\_NAME --no-headers | wc -l)

if [ $count -gt $MAX\_INSTANCES ]; then

echo "Número máximo de instancias ($MAX\_INSTANCES) superado para $PROCESS\_NAME con $count instancias."

fi

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.018.jpeg)

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.019.png)

**Listar todos los procesos de usuarios sin privilegios (UID > 1000)**

#!/bin/bash

ps -eo uid,pid,cmd | awk '$1 > 1000 {print}'

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.020.png)

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.021.jpeg)

DE OTRA MANERA

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.022.png)

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.023.jpeg)

**Alertar sobre procesos que han estado corriendo durante más de X horas**

#!/bin/bash

MAX\_HOURS=24

ps -eo pid,etime | while read pid time; do

days=$(echo $time | grep -oP '^\d+-' | sed 's/-//')

hours=$(echo $time | grep -oP '\d+:' | sed 's/://')

total\_hours=$((days \* 24 + hours))

if [ $total\_hours -gt $MAX\_HOURS ]; then

echo "Proceso $pid ha estado corriendo por más de $MAX\_HOURS horas." fi

done

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.024.jpeg)

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.025.jpeg)

**Encontrar y listar todos los procesos que escuchan en un puerto específico**

#!/bin/bash

PORT="80"

lsof -i :$PORT | awk 'NR > 1 {print $2}' | while read pid; do

ps -p $pid -o pid,cmd

done

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.026.png)

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.027.png)

**Monitorear la memoria utilizada por un conjunto de procesos y alertar si supera un umbral**

#!/bin/bash

PROCESS\_NAME="mysqld"

MAX\_MEM=1024 # 1GB en MB

ps -C $PROCESS\_NAME -o pid,rss | while read pid rss; do

if [ $rss -gt $MAX\_MEM ]; then

echo "Proceso $pid ($PROCESS\_NAME) está utilizando más de $MAX\_MEM MB de memoria."

fi

done

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.028.jpeg)

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.029.png)

**Generar un informe de procesos que incluya PID, tiempo de ejecución y comando**

#!/bin/bash

ps -eo pid,etime,cmd --sort=-etime | head -20 > proceso\_informe.txt echo "Informe generado en proceso\_informe.txt."

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.030.png)

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.031.png)

**El comando grep**

El comando **grep** es una herramienta de línea de comandos disponible en sistemas Unix y Linux utilizada para buscar texto dentro de archivos o flujos de datos. El nombre **grep** proviene de "global regular expression print", refiriéndose a su capacidad para filtrar líneas de texto que coinciden con expresiones regulares especificadas.

**grep** es extremadamente útil para analizar archivos de log, buscar ocurrencias de cadenas de texto en archivos de código, filtrar output de otros comandos, y muchas otras tareas de búsqueda de texto.

En el contexto de la computación paralela, concurrente y distributiva, así como en la automatización, **grep** se puede aplicar de diversas formas:

- **Análisis de logs de aplicaciones distribuidas**: **grep** puede ser utilizado para buscar rápidamente mensajes de error, advertencias o eventos específicos dentro de grandes volúmenes de archivos de log generados por aplicaciones distribuidas, facilitando el diagnóstico de problemas.
- **Monitoreo de salud del sistema**: Al integrarse en scripts de shell, **grep** puede automatizar el monitoreo del estado de servicios y procesos críticos, extrayendo información relevante de comandos como **ps**, **netstat**, o archivos como **/proc/meminfo**.
  - **Validación de configuraciones en clusters**: **grep** puede ser utilizado para verificar rápidamente la consistencia de configuraciones de software en nodos de un cluster, buscando discrepancias o configuraciones erróneas en archivos distribuidos.
    - **Automatización de tareas de gestión**: Integrado en scripts de shell, **grep** puede automatizar la gestión de recursos computacionales, por ejemplo, identificando y

respondiendo a condiciones específicas detectadas en logs o salidas de comandos.

- **Análisis de rendimiento y carga de trabajo**: **grep** es útil para filtrar datos específicos de rendimiento y carga de trabajo de herramientas de monitoreo y métricas, permitiendo a los desarrolladores y administradores centrarse en información relevante para la optimización.

**Ejercicios**

En estos scripts (recuerda son archivos Bash, terminan en .sh) verifica que efectivamente hacen lo que se indica:

**Filtrar errores específicos en logs de aplicaciones paralelas:**

grep "ERROR" /var/log/myapp/\*.log

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.032.png)

**Verificar la presencia de un proceso en múltiples nodos**: pdsh -w nodo[1-10] "ps aux | grep 'my\_process' | grep -v grep"

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.033.png)

**Contar el número de ocurriencias de condiciones de carrera registradas**: grep -c "race condition" /var/log/myapp.log

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.034.png)

**Extraer IPs que han accedido concurrentemente a un recurso**:

grep "accessed resource" /var/log/webserver.log | awk '{print $1}' | sort | uniq

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.035.png)

**Automatizar la alerta de sobrecarga en un servicio distribuido**:

grep "out of memory" /var/log/services/\*.log && mail -s "Alerta de Memoria" admin@example.com < /dev/null

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.036.png)

**Monitorear errores de conexión en aplicaciones concurrentes**:

grep -i "connection error" /var/log/myapp\_error.log | mail -s "Errores de Conexión Detectados" admin@example.com

**Validar la correcta sincronización en operaciones distribuidas**:

grep "operation completed" /var/logs/distributed\_app/\*.log | awk '{print $5, $NF}' | sort

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.037.png)

**Monitorizar la creación de procesos no autorizados**

#!/bin/bash

watch -n 5 'ps aux | grep -vE "(root|daemon|nobody)" | grep -v grep'

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.038.png)

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.039.jpeg)

**Detectar y alertar sobre ataques de fuerza bruta SSH**

grep "Failed password" /var/log/auth.log | cut -d' ' -f11 | sort | uniq -c | sort -nr | head

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.040.png)

**Identificar uso no autorizado de recursos en clústeres de computación**

#!/bin/bash

for host in $(cat hosts.txt); do

ssh $host "ps aux | grep -vE '(ALLOWED\_PROCESS\_1|ALLOWED\_PROCESS\_2)' | grep - v grep"

done

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.041.png)

**Pipes**

Un "pipe" en Linux, simbolizado por |, es una poderosa característica de la línea de comandos que permite pasar la salida (output) de un comando directamente como entrada (input) a otro comando. Esto facilita la creación de secuencias de comandos o pipelines donde el resultado de un proceso es inmediatamente utilizado por otro, permitiendo una manipulación de datos eficiente y flexible sin necesidad de archivos intermedios.

En el contexto de la computación paralela, concurrente y distributiva, los pipes son fundamentales para procesar y analizar datos generados por múltiples procesos, monitorizar el rendimiento y estado de sistemas distribuidos y automatizar tareas administrativas complejas. Al combinar **ps**, **grep** y otros comandos de Linux, se pueden crear pipelines eficientes para la gestión y análisis de sistemas.

**Ejercicios**

Indica las actividades que realizan cada uno de los scripts (recuerda son archivos Bash y por tanto terminan en .sh y cada línea representa un script diferente)

watch "ps aux | grep '[a]pache2' | awk '{print \$1, \$2, \$3, \$4, \$11}'"

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.042.png)

cat /var/log/myapp.log | grep "ERROR" | awk '{print $NF}' | sort | uniq -c | sort -nr

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.043.png)

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.044.png)

systemctl --failed | grep "loaded units listed" || systemctl restart $(awk '{print $1}')

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.045.png)

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.046.png)

ps -eo pid,ppid,%cpu,cmd --sort=-%cpu | awk '$3 > 80 {print "Alto uso de CPU: ", $1}' | mail - s "Alerta CPU" admin@example.com

Con este ejemplo identificamos los procesos que excedan el 80% de uso de la CPU en el sistema y notificar al administrador mediante correo electrónico.

ls /var/log/\*.log | xargs -n 1 -P 5 -I {} ssh nodo\_remoto "grep 'ERROR' {} > errores\_{}.txt"

Este ejemplo explora todos los archivos con extensión ".log" en busca de la palabra "ERROR" y almacena los hallazgos en archivos individuales en el servidor remoto.

echo "8.8.8.8 www.example.com" | xargs -n 1 ping -c 1 | grep "bytes from" || echo "$(date) Fallo de ping" >> fallos\_ping.txt

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.047.png)

pu,%mem,cmd | awk '/httpd/ {cpu+=$2; mem+=$3; count++} END {print "Apache - CPU:", cpu/count, "Mem:", mem/count}'

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.048.png)df /home | awk '$5 > 80 {print $1}' | xargs -I {} tar -czf "{}\_$(date +%F).tar.gz" {} import subprocess

- Ejecutar el comando ps y obtener la salida

result = subprocess.run(['ps', '-eo', '%cpu,pid,cmd'], stdout=subprocess.PIPE) lines = result.stdout.decode('utf-8').strip().split('\n')

- Analizar cada línea de la salida de ps

for line in lines[1:]: # Saltar la primera línea que es la cabecera

cpu\_usage, pid, cmd = line.split(None, 2)

if float(cpu\_usage) > 80.0: # Umbral de uso de CPU

print(f"Alerta: Proceso {pid} ({cmd}) está utilizando {cpu\_usage}% de CPU")

- **Muestra información sobre los procesos en un sistema Unix. Para cada línea de salida (excepto la primera, que es la cabecera), verifica si el uso de CPU supera el 80%. Si es así, emite una alerta indicando el ID del proceso, el comando y el uso de CPU.**

..................................................................................................................................

import subprocess

- Filtrar líneas con errores de un archivo de log

cmd = "grep 'ERROR' /var/log/myapp.log"

errors = subprocess.check\_output(cmd, shell=True).decode('utf-8').split('\n')

- **Busca todas las líneas que contienen la palabra "ERROR" en el archivo de registro /var/log/myapp.log. Luego, lee la salida de este comando utilizando subprocess.check\_output y la decodifica de UTF-8 a una cadena de texto. Finalmente, divide esta cadena en líneas individuales y almacena esas líneas en una lista llamada errors, que contendrá todas las líneas del archivo de registro que contienen la palabra "ERROR"**.
- Analizar errores y contar ocurrencias

error\_counts = {}

for error in errors:

if error in error\_counts:

error\_counts[error] += 1

else:

error\_counts[error] = 1

- **crea un diccionario llamado error\_counts para contar las ocurrencias de cada tipo de error encontrado en la lista errors. Recorre la lista errors y, para cada error, verifica si ya existe una entrada en el diccionario error\_counts. Si el error ya está en el diccionario, incrementa su contador. Si no está en el diccionario, agrega una nueva entrada con un contador inicializado en 1. Al finalizar, el diccionario error\_counts contendrá el recuento de cada tipo de error encontrado en la lista errors**
- Imprimir el recuento de errores

for error, count in error\_counts.items():

print(f"{error}: {count}")

- **muestra cómo imprimir el recuento de errores almacenados en el diccionario error\_counts. Utiliza un bucle for para iterar sobre los elementos del diccionario, donde error es la clave (el tipo de error) y count es el valor (el recuento de ese**

  **tipo de error). Luego, utiliza print para mostrar cada tipo de error junto con su recuento.**

..................................................................................................................................

from multiprocessing import Pool import subprocess

def analyze\_log(file\_part):

"""Función para analizar una parte del archivo de log."""

with open(file\_part) as f:

return f.read().count('ERROR')

- **Define una función llamada analyze\_log que toma una parte del archivo de registro (file\_part) y cuenta las ocurrencias de la cadena 'ERROR' en esa parte del archivo**.
- Dividir el archivo de log en partes

subprocess.run(['split', '-l', '1000', 'large\_log.log', 'log\_part\_'])

- **Utiliza el comando split de Unix para dividir el archivo large\_log.log en partes más pequeñas, cada una con un máximo de 1000 líneas. Las partes resultantes se guardarán con el prefijo log\_part\_.**
- Lista de archivos divididos

parts = subprocess.check\_output('ls log\_part\_\*', shell=True).decode().split()

- **Utiliza el comando ls para obtener una lista de archivos que comienzan con log\_part\_ (los archivos divididos previamente). Luego, utiliza subprocess.check\_output para ejecutar este comando, decodifica la salida en una cadena de texto y la divide en una lista, asignándole a la variable parts**.
- Utilizar multiprocessing para analizar las partes en paralelo with Pool(4) as p:

results = p.map(analyze\_log, parts)

print("Total de errores encontrados:", sum(results))

- **Utiliza la biblioteca multiprocessing para analizar las partes del archivo de registro en paralelo. Con Pool(4) se crea un grupo de procesos, en este caso con 4 procesos. Luego, p.map(analyze\_log, parts) aplica la función analyze\_log a cada elemento de la lista parts utilizando los procesos del grupo, lo que permite procesar varias partes del archivo de registro simultáneamente. Finalmente, suma los resultados de todas las partes para obtener el total de errores encontrados**.

.................................................................................................................................

- import subprocess

import time

previous\_ports = set()

while True:

- I**mportando los módulos subprocess y time. Luego, inicializa un conjunto vacío llamado previous\_ports. A continuación, entra en un bucle infinito (while True:), lo que significa que seguirá ejecutándose continuamente hasta que se detenga manualmente.**
- Ejecutar netstat y capturar la salida

result = subprocess.run(['netstat', '-tuln'], stdout=subprocess.PIPE) ports = set(line.split()[3] for line in result.stdout.decode().split('\n') if 'LISTEN' in line)

- **Utiliza subprocess.run para ejecutar el comando netstat -tuln, que muestra una lista de puertos en escucha en el sistema. La salida de este comando se captura y procesa para extraer los números de puerto que**

  **están en estado de "LISTEN". Estos números de puerto se almacenan en un conjunto llamado ports**

- Detectar cambios en puertos abiertos

new\_ports = ports - previous\_ports

closed\_ports = previous\_ports - ports

if new\_ports or closed\_ports:

print(f"Nuevos puertos abiertos: {new\_ports}, Puertos cerrados: {closed\_ports}")

previous\_ports = ports

time.sleep(60) # Esperar un minuto antes de volver a verificar .................................................................................................................................

- import subprocess
- **Compara el conjunto de puertos actuales (ports) con el conjunto de puertos anteriores (previous\_ports) para detectar cambios en los puertos abiertos. Si hay nuevos puertos abiertos o puertos cerrados en comparación con la última verificación, se imprime un mensaje** **indicando los cambios. Luego, actualiza el conjunto previous\_ports con los puertos actuales y espera 60 segundos antes de realizar la próxima verificación.**
- Obtener uso de memoria por proceso

result = subprocess.run(['ps', '-eo', 'user,rss'], stdout=subprocess.PIPE) lines = result.stdout.decode().split('\n')

- **Ejecuta el comando ps -eo user,rss, que muestra el nombre de usuario y el uso de memoria residente (RSS) de cada proceso en el sistema. La salida de este comando se captura y se divide en líneas, donde cada línea contiene información sobre un proceso.**
- Calcular el uso total de memoria por usuario

memory\_usage = {}

for line in lines[1:-1]: # Ignorar la primera y última línea (cabecera y línea vacía) user, rss = line.split(None, 1)

memory\_usage[user] = memory\_usage.get(user, 0) + int(rss)

for user, rss in memory\_usage.items():

print(f"Usuario: {user}, Memoria RSS total: {rss} KB")

- **Calcula el uso total de memoria por usuario utilizando la salida del comando ps. Crea un diccionario memory\_usage para almacenar el uso de memoria por** **usuario. Luego, itera sobre cada línea de la salida del comando (excepto la primera y la última) y extrae el nombre de usuario y la cantidad de memoria RSS utilizada por el proceso. El código suma la cantidad de memoria utilizada por cada proceso de un mismo usuario y almacena el resultado en el diccionario memory\_usage. Finalmente, imprime el uso total de memoria RSS por cada usuario en el sistema.**

..................................................................................................................................

import subprocess import datetime

snapshot\_interval = 60 # en segundos

while True:

timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

cpu\_usage = subprocess.check\_output("top -b -n1 | awk '/Cpu\(s\):/ {print $2}'", shell=True).decode().strip()

memory\_usage = subprocess.check\_output("free | grep Mem | awk '{print $3/$2 \* 100.0}'", shell=True).decode().strip()

with open("system\_performance.log", "a") as log\_file:

log\_file.write(f"{timestamp}, CPU: {cpu\_usage}%, Memoria: {memory\_usage}%\n")

time.sleep(snapshot\_interval)

- **Crea un bucle infinito que captura el uso de CPU y memoria en intervalos regulares y los guarda en un archivo de registro system\_performance.log. En cada iteración del bucle, se obtiene la marca de tiempo actual y se utiliza subprocess.check\_output para ejecutar comandos que recuperan el uso de CPU y memoria. Estos valores se escriben en el archivo de registro junto con la marca de tiempo. El bucle espera entonces el intervalo especificado antes de tomar otra instantánea del sistema.**

.................................................................................................................................

- #!/bin/bash

while true; do

ps -eo %cpu,pid,cmd --sort=-%cpu | head -n 10 | awk '$1 > 80.0 { printf("Alto uso de CPU (%s%%) por PID %s: %s\n", $1, $2, $3); }' | while read LINE; do

echo "$LINE" | mail -s "Alerta de CPU" admin@domain.com done

sleep 60

done

- **Este script verifica regularmente los procesos con mayor uso de CPU. Si encuentra algún proceso que esté utilizando más del 80% de la CPU, envía una alerta por correo electrónico al administrador. Luego, espera 60 segundos y repite el proceso.**

..................................................................................................................................

#!/bin/bash

while true; do

ps -eo %cpu,pid,cmd --sort=-%cpu | head -n 10 | awk '$1 > 80.0 { printf("Alto uso de CPU (%s%%) por PID %s: %s\n", $1, $2, $3); }' | while read LINE; do

echo "$LINE" | mail -s "Alerta de CPU" admin@domain.com

done

sleep 60

done

- **Este script monitorea constantemente los procesos con mayor uso de CPU. Cada minuto, verifica los 10 procesos con mayor uso de CPU y, si alguno de ellos supera el 80%, envía una alerta por correo electrónico al administrador. Luego, el script espera otros 60 segundos antes de volver a realizar la verificación.**

.................................................................................................................................

- #!/bin/bash

ps -eo user,rss | awk '{arr[$1]+=$2} END {

for (user in arr) {

print user, arr[user] " KB";

}

}' | sort -nrk 2 > /tmp/memory\_usage\_by\_user.txt echo "Uso de memoria por usuario guardado en /tmp/memory\_usage\_by\_user.txt."

- **Este script calcula el uso de memoria por usuario y guarda los resultados en un archivo de texto. Utiliza el comando ps para obtener el nombre de usuario y la memoria residente (RSS) de cada proceso, luego utiliza awk para sumar la memoria de todos los procesos de cada usuario. Finalmente, ordena los resultados por el uso de memoria y los guarda en el archivo /tmp/memory\_usage\_by\_user.txt, mostrando un mensaje de confirmación.**

.................................................................................................................................. #!/bin/bash

echo "Top CPU y Memoria por Usuario"

ps -eo user,%cpu,%mem --sort=-%cpu | awk 'NR==1 {print $0; next} !seen[$1]++' | while read USER CPU MEM; do

echo "Usuario: $USER, CPU: $CPU%, Mem: $MEM%"

done

- **Este script de muestra los principales usuarios en términos de uso de CPU y memoria. Utiliza el comando ps para obtener una lista de procesos ordenados por uso de CPU, luego utiliza awk para mostrar solo la primera línea (encabezado) y la primera instancia de cada usuario. Finalmente, muestra el nombre de usuario, el uso de CPU y el uso de memoria para cada usuario encontrado.**

.................................................................................................................................

- #!/bin/bash

PROCESS\_NAME="java"

echo "Reporte de Memoria para procesos $PROCESS\_NAME"

ps -C $PROCESS\_NAME -o pid,user,%mem,cmd --sort=-%mem | awk 'NR==1; NR>1 {print $0; total+=$3} END {print "Memoria Total Usada:", total "%"}'

- **Este script de genera un informe de uso de memoria para procesos con el nombre "java". Utiliza el comando ps para obtener una lista de procesos java ordenados por uso de memoria. Luego, utiliza awk para mostrar la primera línea (encabezado) y todas las líneas de los procesos java, sumando el uso de memoria de todos los procesos para mostrar la memoria total utilizada por estos procesos al final del informe**

.................................................................................................................................

- #!/bin/bash

LOG="/var/log/httpd/access\_log"

echo "Top IPs"

awk '{print $1}' $LOG | sort | uniq -c | sort -nr | head -5 | while read COUNT IP; do LOCATION=$(geoiplookup $IP | cut -d, -f2)

echo "$IP ($COUNT accesos) - $LOCATION" done

- **Este script de muestra las cinco direcciones IP más frecuentes que acceden al archivo de registro de acceso de HTTP (access\_log). Utiliza awk para extraer las**


**direcciones IP del archivo de registro, luego las ordena y cuenta las apariciones de cada una con uniq -c. Después, las ordena nuevamente por cantidad en orden descendente con sort -nr y muestra solo las cinco primeras con head -5. Para cada una de estas direcciones IP, utiliza geoiplookup para obtener la ubicación geográfica y muestra el resultado junto con el número de accesos.**

..................................................................................................................................

#!/bin/bash

NET\_DEV="eth0"

echo "Estadísticas de red para $NET\_DEV"

rx\_prev=$(cat /sys/class/net/$NET\_DEV/statistics/rx\_bytes) tx\_prev=$(cat /sys/class/net/$NET\_DEV/statistics/tx\_bytes)

sleep 5

rx\_now=$(cat /sys/class/net/$NET\_DEV/statistics/rx\_bytes)

tx\_now=$(cat /sys/class/net/$NET\_DEV/statistics/tx\_bytes)

rx\_rate=$(( ($rx\_now - $rx\_prev) / 5 ))

tx\_rate=$(( ($tx\_now - $tx\_prev) / 5 ))

echo "RX Rate: $rx\_rate bytes/sec"

echo "TX Rate: $tx\_rate bytes/sec"

- **Este script de muestra las estadísticas de red para el dispositivo especificado (eth0 en este caso). Calcula las tasas de recepción y transmisión dividiendo la diferencia en bytes entre dos momentos diferentes (tomados con un intervalo de 5 segundos) por 5 para obtener la tasa por segundo. Luego, muestra estas tasas en bytes por segundo.**

**Bash**

Para profundizar en el aprendizaje y comprensión de Bash en el contexto de computación paralela, concurrente y distribuida, necesitarán una base sólida en varios conceptos y herramientas de línea de comandos. A continuación, les presento una lista de referencias y recursos que pueden ser útiles permitiéndoles no solo entender los scripts proporcionados aquí, sino también desarrollar sus propios scripts para resolver problemas complejos en estos entornos.

"The Linux Command Line" por William Shotts https://linuxcommand.org/tlcl.php

La documentación oficial de Bash es un recurso indispensable para comprender todas las características y capacidades del shell. https://www.gnu.org/software/bash/manual/

Explainshell : https://explainshell.com/

Un sitio web que desglosa comandos de Bash, mostrando una explicación detallada de cada parte de un comando.

Ryan's Tutorials - Bash Scripting Tutorial https://ryanstutorials.net/bash-scripting-tutorial/

Una herramienta de linting para scripts de Bash que ayuda a encontrar errores y problemas comunes en el código. ShellCheck: https://www.shellcheck.net/

Una herramienta para ejecutar tareas en paralelo utilizando la línea de comandos. Es muy útil para procesamiento de datos y tareas computacionales que pueden ser paralelizadas. GNU Parallel https://www.gnu.org/software/parallel/

Para escribir scripts efectivos en Bash, especialmente en el contexto de computación paralela, concurrente y distribuida, es esencial dominar ciertos fundamentos y conceptos avanzados de Bash. A continuación, presento un resumen de los aspectos clave de Bash que debes conocer, acompañados de ejemplos ilustrativos.

**Variables**: Almacenar y manipular datos.

nombre="Mundo" echo "Hola, $nombre"

**Estructuras de Control**: Permiten tomar decisiones y repetir acciones. # If statement

if [ "$nombre" == "Mundo" ]; then

echo "Correcto"

fi

- Loop

for i in {1..5}; do

echo "Iteración $i"

done

**Funciones**: Agrupar código para reutilizar.

saludo() {

echo "Hola, $1"

}

saludo "Mundo"

**Comandos comunes** (**grep**, **awk**, **sed**, **cut**, **sort**, **uniq**): Procesamiento de texto y datos. echo -e "manzana\nbanana\nmanzana" | sort | uniq

**Pipes y redirecciones**: Conectar la salida de un comando con la entrada de otro. cat archivo.txt | grep "algo" > resultado.txt

**Expresiones regulares**: Patrones para buscar y manipular texto.

echo "error 404" | grep -Eo "[0-9]+"

**Manejo de argumentos**: Scripts que aceptan entrada del usuario. #!/bin/bash

echo "Ejecutando script con el argumento: $1"

**Automatización y monitoreo**: Scripts para automatizar tareas y monitorear sistemas. #!/bin/bash

if ps aux | grep -q "[a]pache2"; then

echo "Apache está corriendo."

else

echo "Apache no está corriendo."

fi

**Procesamiento Paralelo con GNU Parallel**: Ejecutar tareas en paralelo para optimizar el tiempo de procesamiento.

cat lista\_urls.txt | parallel wget

**Validación de entradas**: Prevenir la ejecución de comandos maliciosos.

read -p "Introduce tu nombre: " nombre

echo "Hola, $nombre" # Asegúrate de validar o escapar $nombre si se usa en comandos más complejos.

**Optimización de scripts**: Utilizar herramientas y técnicas para reducir el tiempo de ejecución.

find . -name "\*.txt" | xargs grep "patrón" **Ejercicios**

Indica las actividades que realizan cada uno de los scripts (recuerda son archivos Bash y por tanto terminan en .sh.

#!/bin/bash

- Configuración

UMBRAL\_CPU=70.0 # Uso máximo de CPU permitido (%) UMBRAL\_MEM=500 # Uso máximo de memoria permitido (MB) LOG\_FILE="/var/log/monitoreo\_procesos.log" EMAIL\_ADMIN="admin@ejemplo.com"

PROCESOS\_PARALELOS=("proceso1" "proceso2" "proceso3") # Nombres de los procesos a monitorear

- Función para convertir memoria de KB a MB convertir\_kb\_a\_mb() {

echo "$(( $1 / 1024 ))"

}

- Función para obtener y verificar el uso de recursos de los procesos verificar\_procesos() {

for PROC in "${PROCESOS\_PARALELOS[@]}"; do

ps -C $PROC -o pid=,%cpu=,%mem=,vsz=,comm= --sort=-%cpu | while read PID CPU

MEM VSZ COMM; do

MEM\_MB=$(convertir\_kb\_a\_mb $VSZ)

if (( $(echo "$CPU > $UMBRAL\_CPU" | bc -l) )) || [ "$MEM\_MB" -gt "$UMBRAL\_MEM" ]; then

echo "$(date +"%Y-%m-%d %H:%M:%S") - Proceso $COMM (PID $PID) excede los umbrales con CPU: $CPU%, MEM: ${MEM\_MB}MB" >> $LOG\_FILE

kill -9 $PID && echo "$(date +"%Y-%m-%d %H:%M:%S") - Proceso $PID terminado." >> $LOG\_FILE

echo "Proceso $PID ($COMM) terminado por alto uso de recursos" | mail -s "Alerta de Proceso Terminado" $EMAIL\_ADMIN

fi done done

}

- Loop principal para el monitoreo continuo

while true; do

verificar\_procesos

sleep 60 # Espera 60 segundos antes de la próxima verificación done

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.049.jpeg)

- **Este script monitorea continuamente el uso de CPU y memoria de los procesos especificados en PROCESOS\_PARALELOS. Cada minuto, verifica si alguno de estos procesos supera los umbrales de uso de CPU (UMBRAL\_CPU) o de memoria (UMBRAL\_MEM). Si un proceso excede alguno de estos umbrales, se registra en un archivo de registro (LOG\_FILE), se detiene con kill -9 y se envía una alerta por correo electrónico al administrador (EMAIL\_ADMIN)**

.................................................................................................................................

- #!/bin/bash

DIRECTORIOS=("dir1" "dir2" "dir3") DESTINO\_BACKUP="/mnt/backup"

backup\_dir() {

dir=$1

fecha=$(date +%Y%m%d)

tar -czf "${DESTINO\_BACKUP}/${dir##\*/}\_$fecha.tar.gz" "$dir" echo "Backup completado para $dir"

}

export -f backup\_dir

export DESTINO\_BACKUP

parallel backup\_dir ::: "${DIRECTORIOS[@]}"

- **Este script realiza copias de seguridad de varios directorios en paralelo utilizando el comando tar. Cada directorio se comprime en un archivo .tar.gz con la fecha actual en el nombre y se guarda en un directorio de destino de backup. Utiliza el programa parallel para ejecutar las copias de seguridad en paralelo, lo que puede mejorar la eficiencia en sistemas con varios núcleos de CPU**

.................................................................................................................................

- #!/bin/bash

NODOS=("nodo1" "nodo2" "nodo3")

TAREAS=("tarea1.sh" "tarea2.sh" "tarea3.sh")

distribuir\_tareas() {

for i in "${!TAREAS[@]}"; do

nodo=${NODOS[$((i % ${#NODOS[@]}))]} tarea=${TAREAS[$i]}

echo "Asignando $tarea a $nodo"

scp "$tarea" "${nodo}:/tmp"

ssh "$nodo" "bash /tmp/$tarea" &

done

wait

}

distribuir\_tareas

- **Este script de distribuye tareas a nodos en una red. Utiliza un bucle para asignar cada tarea (TAREAS) a un nodo (NODOS). Utiliza scp para copiar la tarea al nodo y luego ejecuta la tarea en el nodo usando ssh. Las tareas se ejecutan en paralelo en los nodos. Finalmente, espera a que todas las tareas finalicen antes de continua**

.................................................................................................................................

- #!/bin/bash

LOCK\_FILE="/var/lock/mi\_recurso.lock" RECURSO="/path/to/recurso\_compartido"

adquirir\_lock() {

while ! (set -o noclobber; > "$LOCK\_FILE") 2> /dev/null; do echo "Esperando por el recurso..."

sleep 1

done

}

liberar\_lock() {

rm -f "$LOCK\_FILE" }

adquirir\_lock

- Trabajar con el recurso

echo "Accediendo al recurso"

sleep 5 # Simular trabajo

liberar\_lock

- **Este script gestiona un bloqueo de recurso compartido utilizando un archivo de bloqueo (LOCK\_FILE). La función adquirir\_lock intenta adquirir el bloqueo del recurso, esperando si el bloqueo está en uso. Una vez adquirido el bloqueo, el script realiza alguna tarea con el recurso compartido (simulada con sleep 5 en este caso) y luego libera el bloqueo con la función liberar\_lock, eliminando el archivo de bloqueo**

.................................................................................................................................

- #!/bin/bash

NODOS=("nodo1" "nodo2" "nodo3") ARCHIVO\_METRICAS="/tmp/metricas\_$(date +%Y%m%d).csv"

recolectar\_metricas() {

echo "Nodo,CPU(%),Memoria(%),Disco(%)" > "$ARCHIVO\_METRICAS" for nodo in "${NODOS[@]}"; do

ssh "$nodo" "


cpu=\$(top -bn1 | grep 'Cpu(s)' | sed 's/.\*, \*\([0-9.]\*\)%\* id.\*/\1/' | awk '{print 100 - \$1}'); memoria=\$(free | awk '/Mem:/ {print \$3/\$2 \* 100.0}');

disco=\$(df / | awk 'END{print $(NF-1)}');

echo \"\$HOSTNAME,\$cpu,\$memoria,\$disco\"; " >> "$ARCHIVO\_METRICAS" done

}

recolectar\_metricas

- **Recopila métricas de CPU, memoria y disco de varios nodos en una red. Utiliza un bucle para iterar sobre los nodos (NODOS) y, para cada nodo, se conecta mediante SSH para ejecutar comandos que obtienen las métricas de CPU, memoria y disco. Luego, las métricas se agregan a un archivo CSV (ARCHIVO\_METRICAS) para su posterior análisis**

**awk**

Awk es una herramienta de scripting extremadamente poderosa y versátil para procesar y analizar datos en Unix/Linux. Es especialmente útil para manipular datos textuales y produce resultados formatados. **awk** funciona leyendo archivos o flujos de entrada línea por línea, dividiendo cada línea en campos, procesándola con acciones definidas por el usuario y luego imprimiendo la salida.

En el contexto de la computación paralela y concurrente, **awk** puede ser utilizado para analizar y procesar datos generados por procesos, monitorizar el rendimiento del sistema, y preparar datos para ser procesados en paralelo. Cuando se combina con pipes de Linux y expresiones regulares, **awk** se convierte en una herramienta aún más potente, permitiendo a los usuarios filtrar, procesar y redirigir la salida de comandos en secuencias complejas de operaciones.

**awk** puede ser usado para extraer información específica de la lista de procesos generada por el comando **ps**.

ps aux | awk '{print $1, $2, $3, $4, $11}' | head -n 10

Pregunta: ¿Qué hace y cual es el resultado del código anterior?

**awk** puede ser utilizado para preparar y filtrar datos que necesiten ser procesados en paralelo. Por ejemplo, puedes dividir un archivo grande en múltiples archivos más pequeños basados en algún criterio, que luego pueden ser procesados en paralelo:

awk '{print > ("output" int((NR-1)/1000) ".txt")}' input.txt

Pregunta: Comprueba con este archivo de texto el anterior script: https://babel.upm.es/~angel/teaching/pps/quijote.txt

La combinación de **awk** con pipes y expresiones regulares expande significativamente sus capacidades de procesamiento de texto. Por ejemplo, para monitorizar archivos de log en busca de errores y filtrar mensajes relevantes:

tail -f /var/log/app.log | grep "ERROR" | awk '{print $1, $2, $NF}'

Pregunta: ¿puedes comprobar cual es el resultado si aplicas el script anterior en tus archivos logs?

Pregunta: ¿cuál es el resultado de utilizar este script (usa apache)?

ps -eo user,pid,pcpu,pmem,cmd | grep apache2 | awk '$3 > 50.0 || $4 > 50.0 {print "Alto recurso: ", $0}'

**Ejercicios:**

¿Cuál es la salida de los siguientes scripts (recuerda que son archivos de texto en bash)

1. ps -eo pid,pcpu,pmem,cmd | awk '$2 > 10.0 || $3 > 10.0'

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.050.png)

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.051.png)

2. awk '{print $0 >> ("output-" $4 ".log")}' /var/log/syslog

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.052.png)

3. grep "Failed password" /var/log/auth.log | awk '{print $(NF-3)}' | sort | uniq -c | sort -nr

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.053.png)

4. inotifywait -m /path/to/dir -e create | awk '{print "Nuevo archivo creado:", $3}' 5. find . -type f -name "\*.py" -exec ls -l {} + | awk '{sum += $5} END {print "Espacio total usado por archivos .py: ", sum}'
6. awk '{sum+=$NF} END {print "Tiempo promedio de respuesta:", sum/NR}' access.log
6. ps -eo state | awk '/D/ {d++} /R/ {r++} END {print "Espera (D):", d, "- Ejecución (R):",

r}'

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.054.png)

8. ps -eo state | awk '/D/ {d++} /R/ {r++} END {print "Espera (D):", d, "- Ejecución (R):", r}'

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.055.png)

9. awk '/SwapTotal/ {total=$2} /SwapFree/ {free=$2} END {if ((total-free)/total\*100 >

20\.0) print "Alerta: Uso excesivo de swap"}' /proc/meminfo

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.056.png)

10. ls -l | awk '!/^total/ && !/^d/ {sum += $5} END {print "Uso total de disco (sin subdirectorios):", sum}'

![](Aspose.Words.e3c7ce6e-b3fd-4494-84b6-5c674afa29c9.057.png)

Computación Paralela y Distribuida
