﻿**Departamento Académico de Ingeniería ![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.001.png)C8286-Computación Paralela y Distribuida** 

**Evaluación: Módulos 2 y 3 AWS Data Engineering**

- Identificar las principales características y funciones de Amazon S3 que permiten el acceso y análisis de datos.
- Describir cómo se utilizan los servicios de Amazon S3 para almacenar y recuperar grandes volúmenes de datos.
- Configurar un bucket de Amazon S3 para almacenar datos de manera eficiente. • Comparar las ventajas de usar Amazon S3 frente a otras soluciones de almacenamiento de datos en términos de coste y rendimiento.
- Evaluar las implicaciones de seguridad y privacidad al utilizar Amazon S3 en proyectos de análisis de datos
- Enumerar los cinco Vs de los datos: volumen, velocidad, variedad, veracidad y valor. • Explicar cómo cada uno de los cinco Vs afecta la captura, el procesamiento y la visualización de datos.
- Utilizar un ejemplo práctico para demostrar cómo planificar y configurar una pipeline de datos considerando los cinco Vs
- Analizar los diferentes tipos de variabilidad de los datos (velocidad, volumen, etc.) influyen en las decisiones tecnológicas para proyectos de big data. • datos haya impactado negativamente en los resultados del análisis de datos. • Desarrollar un plan estratégico para implementar una pipeline de datos efectiva que maneje adecuadamente los cinco Vs y maximice el valor de los datos para una organización específica.

**Instrucciones de entrega:**

- Crea un documento en markdown que incluya una breve explicación de las partes que creas más importantes de tus respuestas junto con las capturas de pantalla o texto correspondiente del laboratorio: Lab: Accessing and Analyzing Data by Using Amazon S3
- Para el módulo 3 presenta la verificación del Knowledge Check
- Subir el documento final a tu repositorio personal hasta el día 5 de mayo (23:59).

**Identificar las principales características y funciones de Amazon S3 que permiten el acceso y análisis de datos:**

- Amazon S3 es un servicio de almacenamiento de objetos escalable y duradero, que permite almacenar y recuperar cualquier cantidad de datos, desde cualquier lugar de la web.
- Algunas características clave de S3 que facilitan el acceso y análisis de datos son:
  - Escalabilidad ilimitada para almacenar grandes volúmenes de datos.
  - Múltiples clases de almacenamiento para optimizar el costo y el acceso.
  - Integración con otros servicios AWS como Athena, Redshift y EMR para análisis de datos.
  - Controles de acceso y seguridad flexibles para gestionar permisos.

**Describir cómo se utilizan los servicios de Amazon S3 para almacenar y recuperar grandes volúmenes de datos:**

- Los datos se pueden cargar en S3 a través de diversos mecanismos como la consola web, la CLI o SDK.
- Los objetos almacenados en S3 se organizan en "buckets" (cubos) que actúan como contenedores lógicos.
- S3 escala automáticamente para almacenar y procesar grandes cantidades de datos sin necesidad de aprovisionar.
- Los datos se pueden recuperar a través de consultas y descargas, o integrándolos con otros servicios analíticos de AWS.

**Configurar un bucket de Amazon S3 para almacenar datos de manera eficiente:**

- Definir una estructura de carpetas y nomenclatura para organizar los datos.
- Elegir la clase de almacenamiento adecuada según el patrón de acceso esperado.
- Habilitar características como versionamiento, ciclo de vida y cifrado para proteger los datos.
- Configurar políticas de acceso y permisos para controlar quién puede acceder a los datos.

**Comparar las ventajas de usar Amazon S3 frente a otras soluciones de almacenamiento de datos en términos de costo y rendimiento:**

- S3 ofrece un almacenamiento escalable y de bajo costo, especialmente para grandes volúmenes de datos.
- Proporciona un alto rendimiento y disponibilidad, adecuado para cargas de trabajo de análisis.
- Permite pagar solo por lo que se usa, sin necesidad de aprovisionar capacidad.
- Otras soluciones pueden tener costos más altos o requerir más mantenimiento y gestión por parte del usuario.

**Evaluar las implicaciones de seguridad y privacidad al utilizar Amazon S3 en proyectos de análisis de datos:**

- S3 proporciona controles de acceso flexibles y cifrado de datos en reposo y en tránsito.
- Es necesario configurar adecuadamente los permisos y políticas de acceso para evitar accesos no autorizados.
- Hay que considerar la ubicación geográfica de los buckets y cumplir con las regulaciones de privacidad de datos.
- Implementar prácticas de seguridad como registro de auditoría, monitoreo y

  protección contra pérdida de datos.

**Enumerar los cinco Vs de los datos: volumen, velocidad, variedad, veracidad y valor.**

**Explicar cómo cada uno de los cinco Vs afecta la captura, el procesamiento y la visualización de datos:**

- **Volumen**: Impacta el diseño de la infraestructura de almacenamiento y procesamiento para manejar grandes cantidades de datos.
- **Velocidad**: Afecta la elección de tecnologías y arquitecturas para ingerir, procesar y analizar datos en tiempo real o por lotes.
- **Variedad**: Exige la capacidad de manejar diferentes formatos y estructuras de datos, y realizar transformaciones para integrarlos.
- **Veracidad:** Requiere procesos de limpieza, validación y gobernanza de datos para garantizar su integridad y fiabilidad.
- **Valor:** Determina qué datos son relevantes y valiosos para los objetivos de negocio, guiando las decisiones de captura y análisis.

**Utilizar un ejemplo práctico para demostrar cómo planificar y configurar una pipeline de datos considerando los cinco Vs:**

Por ejemplo:

Una empresa de comercio electrónico que quiere analizar el comportamiento de los clientes en su sitio web.

**Volumen:** Capturar y procesar registros de clics y eventos de navegación a gran escala. **Velocidad:** Ingerir y procesar los datos de clics en tiempo real para realizar recomendaciones personalizadas.

**Variedad**: Integrar datos estructurados (transacciones) y no estructurados (text, imágenes) de diferentes fuentes.

**Veracidad:** Implementar procesos de limpieza y validación de datos para garantizar su integridad.

**Valor:** Identificar los datos más relevantes para analizar el comportamiento del cliente y mejorar la experiencia.

**Analizar cómo los diferentes tipos de variabilidad de los datos (velocidad, volumen, etc.) influyen en las decisiones tecnológicas para proyectos de big data:**

- El alto volumen de datos requerirá soluciones de almacenamiento escalables como Amazon S3.
- La necesidad de procesar datos en tiempo real implicará el uso de tecnologías de streaming como Amazon Kinesis.
- La variedad de datos estructurados y no estructurados sugerirá la adopción de plataformas flexibles como Amazon EMR.
- La veracidad de los datos impulsará la implementación de procesos de limpieza, validación y gobernanza.

**Desarrollar un plan estratégico para implementar una pipeline de datos efectiva que maneje adecuadamente los cinco Vs y maximice el valor de los datos para una organización específica:**

- Evaluar las necesidades de la organización en cuanto a los cinco Vs de los datos.
- Diseñar una arquitectura de pipeline de datos que incluya servicios como S3, Kinesis, Glue, Athena, etc.
- Implementar procesos de gobernanza de datos, limpieza, transformación e integración.
- Establecer mecanismos de visualización y análisis para extraer insights valiosos.
- Monitorizar y optimizar continuamente la pipeline para adaptarse a los cambios en los requisitos de datos.

**Lab:Accessing and Analyzing Data by Using Amazon S3**

**Tarea 1: Crear una plantilla y una pila de CloudFormation**

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.002.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.003.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.004.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.005.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.006.png)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.007.png)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.008.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.009.jpeg)

elimina

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.010.png)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.011.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.012.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.013.png)

**Tarea 2: cargar datos de muestra en un depósito de S3**

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.014.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.015.png)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.016.png)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.017.png)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.018.png)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.019.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.020.png)

**Tarea 3: Consultar los datos**

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.021.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.022.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.023.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.024.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.025.png)

**Tarea 4: Modificar las propiedades de cifrado y el tipo de**

**almacenamiento de un objeto**

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.026.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.027.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.028.jpeg)

**Tarea 5: comprimir y consultar el conjunto de datos**

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.029.png)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.030.png)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.031.png)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.032.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.033.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.034.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.035.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.036.jpeg)

**Tarea 6: Administrary probar el acceso restringido para un miembro**

**del equipo**

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.037.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.038.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.039.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.040.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.041.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.042.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.043.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.044.jpeg)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.045.png)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.046.png)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.047.png)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.048.png)

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.049.jpeg)

Module 2

![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.050.jpeg)



|Module 3||
| - | :- |
|![](Aspose.Words.bff69bc1-086b-484a-903a-52efd59eeddc.051.jpeg)||

